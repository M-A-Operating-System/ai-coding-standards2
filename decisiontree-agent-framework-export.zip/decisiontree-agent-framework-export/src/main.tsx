import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { EmbedPage } from './pages/EmbedPage';

// Minimal path-based router — no library dependency needed.
// /embed  → frameless embed view (used inside iframes)
// anything else → full app shell
const { pathname } = window.location;
const isEmbed = pathname === '/embed' || pathname.startsWith('/embed/');

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    {isEmbed ? <EmbedPage /> : <App />}
  </React.StrictMode>
);

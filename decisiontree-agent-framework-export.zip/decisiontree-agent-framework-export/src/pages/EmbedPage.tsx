/**
 * decision-dag — EmbedPage
 *
 * Rendered at /embed?dsl=<encoded> — no app chrome, just the interactive
 * PathVisualisation component in a clean frameless layout.
 * Intended to be loaded inside a host site's <iframe>.
 */

import React, { useMemo } from 'react';
import { PathVisualisation } from '../components/PathVisualisation';
import { parseDSL } from '../lib/dag-parser';
import { decodeDsl } from '../lib/embed-utils';

function parseParams(): { token: string | null } {
  const params = new URLSearchParams(window.location.search);
  return { token: params.get('dsl') };
}

export function EmbedPage() {
  const { token } = useMemo(parseParams, []);

  const result = useMemo(() => {
    if (!token) return { dag: null, error: 'No DAG provided.' };
    try {
      const dsl = decodeDsl(token);
      const { dag } = parseDSL(dsl);
      return { dag, error: null };
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : String(e);
      return { dag: null, error: msg };
    }
  }, [token]);

  if (result.error || !result.dag) {
    return (
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          minHeight: '100vh',
          padding: 32,
          fontFamily: 'system-ui, sans-serif',
          textAlign: 'center',
          background: '#fafaf9',
        }}
      >
        <div
          style={{
            fontSize: 32,
            marginBottom: 16,
            opacity: 0.4,
          }}
        >
          ⚠
        </div>
        <div
          style={{
            fontSize: 16,
            fontWeight: 500,
            color: '#333',
            marginBottom: 8,
          }}
        >
          Invalid or expired embed link
        </div>
        <div
          style={{
            fontSize: 13,
            color: '#888',
            maxWidth: 380,
            lineHeight: 1.5,
          }}
        >
          {result.error}
        </div>
      </div>
    );
  }

  return (
    <div
      style={{
        padding: '20px 20px 40px',
        background: '#fff',
        minHeight: '100vh',
        boxSizing: 'border-box',
      }}
    >
      <PathVisualisation dag={result.dag} />
    </div>
  );
}

/**
 * Utilities for encoding/decoding a DAG DSL string into a URL-safe token.
 *
 * Encoding: UTF-8 bytes → base64url (no padding, URL-safe alphabet).
 * Decoding: reverse.
 *
 * Safe for DAGs containing any Unicode characters.
 */

/** Encode a DSL string to a URL-safe base64 token. */
export function encodeDsl(dsl: string): string {
  // Encode to UTF-8 bytes, then to binary string for btoa
  const bytes = new TextEncoder().encode(dsl);
  const binary = Array.from(bytes, (b) => String.fromCharCode(b)).join('');
  const b64 = btoa(binary);
  // Convert to URL-safe base64url (no padding)
  return b64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

/** Decode a URL-safe base64 token back to the original DSL string. */
export function decodeDsl(token: string): string {
  // Restore standard base64 alphabet
  const b64 = token.replace(/-/g, '+').replace(/_/g, '/');
  // Restore padding so length is a multiple of 4
  const paddingLength = (4 - (b64.length % 4)) % 4;
  const paddedB64 = paddingLength ? b64 + '='.repeat(paddingLength) : b64;
  // Decode binary string back to UTF-8 bytes
  const binary = atob(paddedB64);
  const bytes = Uint8Array.from(binary, (c) => c.charCodeAt(0));
  return new TextDecoder().decode(bytes);
}

/** Build the full embed URL for a given encoded DSL token. */
export function buildEmbedUrl(baseUrl: string, encodedDsl: string): string {
  // Normalize: strip any trailing slash to avoid double slashes
  const base = baseUrl.endsWith('/') ? baseUrl.slice(0, -1) : baseUrl;
  const url = new URL(`${base}/embed`);
  url.searchParams.set('dsl', encodedDsl);
  return url.toString();
}

/**
 * decision-dag — type definitions
 * Schema version: 1.0.0
 *
 * These types are the canonical contract for the DecisionDAG format.
 * Both the DSL compiler and the wizard runtime consume these types.
 */

// ── Input types ────────────────────────────────────────────────────────────

export interface ChoiceOption {
  readonly value: string;
  readonly label: string;
  readonly description?: string;
}

export type QuestionInput =
  | {
      readonly type: 'binary';
      readonly yes_label?: string;
      readonly no_label?: string;
    }
  | {
      readonly type: 'choice';
      readonly options: ReadonlyArray<ChoiceOption>;
    };

// ── Edge ──────────────────────────────────────────────────────────────────

export interface Edge {
  /** The answer value that triggers this edge (e.g. "yes", "no", "A") */
  readonly answer: string;
  /** Target node ID — must exist in dag.nodes */
  readonly next: string;
  /** Optional display label rendered on the edge in diagram views */
  readonly label?: string;
}

// ── Display hints (renderer-facing, all optional) ─────────────────────────

export interface DisplayHints {
  readonly color?: string;
  readonly icon?: string;
  readonly position?: { x: number; y: number };
}

// ── Nodes ─────────────────────────────────────────────────────────────────

export interface QuestionNode {
  readonly id: string;
  readonly kind: 'question';
  readonly text: string;
  readonly hint?: string;
  readonly input: QuestionInput;
  /** decision mode: edges to next nodes */
  readonly edges: ReadonlyArray<Edge>;
  /** elimination mode: maps answer value → outcome IDs that answer keeps alive */
  readonly routes?: Readonly<Record<string, ReadonlyArray<string>>>;
  readonly display?: DisplayHints;
}

export interface OutcomeNode {
  readonly id: string;
  readonly kind: 'outcome';
  readonly label: string;
  readonly description?: string;
  /**
   * Stable machine-readable code consumed by downstream systems.
   * Unlike `label`, this should never change between versions.
   */
  readonly code?: string;
  /**
   * Open envelope — any domain-specific data (URLs, actions, metadata).
   * The schema does not constrain its shape; consuming systems own this contract.
   */
  readonly payload?: Record<string, unknown>;
  readonly display?: DisplayHints;
}

export type DAGNode = QuestionNode | OutcomeNode;

// ── Document ──────────────────────────────────────────────────────────────

export interface DecisionDAG {
  readonly $schema_version: '1.0.0';
  readonly id: string;
  readonly name?: string;
  readonly version?: string;
  readonly locale?: string;
  /**
   * Tree mode:
   *   decision   — questions carry edges to the next node (default, backwards-compatible)
   *   elimination — questions carry routes that filter outcomes; no next-question edges
   */
  readonly mode?: 'decision' | 'elimination';
  /** ID of the first QuestionNode to display */
  readonly entry: string;
  /**
   * Ordered list of question IDs for elimination mode.
   * Questions are asked in this sequence regardless of answer; outcomes are
   * progressively eliminated until one (or a ranked set) remains.
   */
  readonly questionOrder?: ReadonlyArray<string>;
  readonly meta?: {
    readonly author?: string;
    readonly created_at?: string;
    readonly updated_at?: string;
    readonly description?: string;
    readonly tags?: ReadonlyArray<string>;
  };
  readonly nodes: Readonly<Record<string, DAGNode>>;
  readonly routes?: ReadonlyArray<Route>;
}

export interface Route {
  readonly path: ReadonlyArray<{ question: string; answers: string[] }>;
  readonly outcomeId: string;
}
// ── Type guards ────────────────────────────────────────────────────────────

export function isQuestionNode(node: DAGNode): node is QuestionNode {
  return node.kind === 'question';
}

export function isOutcomeNode(node: DAGNode): node is OutcomeNode {
  return node.kind === 'outcome';
}

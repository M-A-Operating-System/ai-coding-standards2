/**
 * decision-dag — DSL parser
 *
 * Compiles the human-authored .dag text format into a validated DecisionDAG
 * document. This is a pure function with no side effects.
 *
 * DSL grammar (line-oriented):
 *
 *   dag: <name>                  — document name
 *   version: <semver>            — content version (independent of schema version)
 *   entry: <nodeId>              — ID of the first question node
 *   mode: decision|elimination   — tree mode (default: decision)
 *   # comment                   — ignored entirely
 *
 *   <ID>: <question text>        — define a question node (decision mode)
 *     yes -> <ID>                — binary yes edge
 *     no  -> <ID>                — binary no edge
 *     A: <label> -> <ID>         — choice edge (A–F)
 *     hint: <text>               — optional hint shown below the question
 *
 *   <ID>: <question text>        — define a question node (elimination mode)
 *     routes:
 *       yes -> [OUT1, OUT2]      — outcomes kept alive by this answer
 *       no  -> [OUT3]
 *
 *   [<ID>]: <label>              — define an outcome node
 *     description: <text>        — optional description
 *     code: <MACHINE_CODE>       — optional stable machine key
 *
 *   routes:                      — document-level explicit path → outcome table
 *     Q1=yes, Q2=A -> [OUT_X]
 */

import type {
  DecisionDAG,
  DAGNode,
  QuestionNode,
  OutcomeNode,
  Route,
  Edge,
  ChoiceOption,
  QuestionInput,
} from './dag-types';

// ── Utilities ─────────────────────────────────────────────────────────────

function generateUUID(): string {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
  });
}

// ── Parse result ──────────────────────────────────────────────────────────

export interface ParseResult {
  readonly dag: DecisionDAG;
  /** Node IDs that have more than one incoming edge (DAG, not pure tree) */
  readonly sharedNodes: ReadonlyArray<string>;
  /** Node IDs reachable from entry */
  readonly reachableNodes: ReadonlyArray<string>;
  /** Node IDs defined but never referenced (orphans) */
  readonly orphanNodes: ReadonlyArray<string>;
}

export interface ParseError {
  readonly message: string;
  readonly line?: number;
}

// ── Document-level routes section parser ─────────────────────────────────

/**
 * Parse the document-level routes: section.
 * Each line defines an explicit answer-path → outcome mapping:
 *   Q1=yes, Q2=A|B -> [OUT_X]
 */
function parseRoutesSection(lines: string[]): Route[] {
  const routes: Route[] = [];
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const arrowIdx = trimmed.indexOf('->');
    if (arrowIdx === -1) continue;
    const pathPart = trimmed.slice(0, arrowIdx);
    const outcomePart = trimmed.slice(arrowIdx + 2);
    const path = pathPart
      .split(',')
      .map((seg) => {
        const eqIdx = seg.indexOf('=');
        if (eqIdx === -1) return null;
        const question = seg.slice(0, eqIdx).trim();
        const answers = seg.slice(eqIdx + 1).split('|').map((a) => a.trim());
        return question ? { question, answers } : null;
      })
      .filter((s): s is { question: string; answers: string[] } => s !== null);
    const outcomeIdMatch = outcomePart.match(/\[(.+?)\]/);
    if (!outcomeIdMatch) continue;
    routes.push({ path, outcomeId: outcomeIdMatch[1].trim() });
  }
  return routes;
}

// ── Parser ────────────────────────────────────────────────────────────────

/**
 * Parse DSL source text into a validated DecisionDAG.
 * Throws ParseError on any structural or referential violation.
 */
export function parseDSL(source: string): ParseResult {
  const allLines = source.split(/\r?\n/);

  const nodes: Record<string, DAGNode> = {};
  const incomingEdges: Record<string, string[]> = {};
  const questionOrder: string[] = [];
  let name = '';
  let version = '1.0.0';
  let entry = '';
  let mode: 'decision' | 'elimination' = 'decision';
  let currentQuestionId: string | null = null;
  let currentOutcomeId: string | null = null;
  // tracks whether we are inside a per-question `routes:` block (elimination mode)
  let inRoutesBlock = false;

  // Extract and parse the document-level routes: section if present.
  // It must appear as a top-level (non-indented) "routes:" line.
  const routesSectionStart = allLines.findIndex(
    (l) => l.trim().toLowerCase() === 'routes:' && !l.startsWith(' ') && !l.startsWith('\t')
  );
  let docRoutes: Route[] | undefined = undefined;
  const lines = routesSectionStart !== -1 ? allLines.slice(0, routesSectionStart) : allLines;
  if (routesSectionStart !== -1) {
    const routeLines: string[] = [];
    for (let i = routesSectionStart + 1; i < allLines.length; ++i) {
      const l = allLines[i];
      if (!l.trim() || (!l.startsWith(' ') && !l.startsWith('\t'))) break;
      routeLines.push(l);
    }
    docRoutes = parseRoutesSection(routeLines);
  }

  for (let i = 0; i < lines.length; i++) {
    const lineNum = i + 1;
    // Strip inline comments and trailing whitespace
    const line = lines[i].replace(/#.*$/, '').trimEnd();
    if (!line.trim()) continue;

    const isIndented = line.startsWith('  ') || line.startsWith('\t');

    // ── Header directives ─────────────────────────────────────────
    if (/^dag:\s+/.test(line)) {
      name = line.replace(/^dag:\s+/, '').trim();
      currentQuestionId = null;
      currentOutcomeId = null;
      inRoutesBlock = false;
      continue;
    }
    if (/^version:\s+/.test(line)) {
      version = line.replace(/^version:\s+/, '').trim();
      continue;
    }
    if (/^entry:\s+/.test(line)) {
      entry = line.replace(/^entry:\s+/, '').trim();
      continue;
    }
    if (/^mode:\s+/.test(line)) {
      const modeVal = line.replace(/^mode:\s+/, '').trim();
      if (modeVal !== 'decision' && modeVal !== 'elimination') {
        throw makeError(
          `Invalid mode "${modeVal}". Must be "decision" or "elimination"`,
          lineNum
        );
      }
      mode = modeVal;
      continue;
    }

    // ── Outcome definition: [OUT_ID]: Label ───────────────────────
    const outcomeMatch = line.match(/^\[([A-Z0-9_]+)\]:\s*(.+)$/);
    if (outcomeMatch) {
      const [, id, label] = outcomeMatch;
      if (nodes[id]) {
        throw makeError(`Duplicate node ID "${id}"`, lineNum);
      }
      nodes[id] = { id, kind: 'outcome', label: label.trim() };
      currentQuestionId = null;
      currentOutcomeId = id;
      inRoutesBlock = false;
      continue;
    }

    // ── Outcome child attributes (indented under [OUT_ID]) ────────
    if (isIndented && currentOutcomeId) {
      const trimmed = line.trim();
      const outcome = nodes[currentOutcomeId] as OutcomeNode;
      const descMatch = trimmed.match(/^description:\s*(.+)$/);
      if (descMatch) {
        nodes[currentOutcomeId] = { ...outcome, description: descMatch[1].trim() };
        continue;
      }
      const codeMatch = trimmed.match(/^code:\s*([A-Z0-9_]+)$/);
      if (codeMatch) {
        nodes[currentOutcomeId] = { ...outcome, code: codeMatch[1].trim() };
        continue;
      }
      // Unknown indented line under outcome — ignore gracefully
      continue;
    }

    // ── Question definition: Q1: Question text? ───────────────────
    const questionMatch = line.match(/^([A-Za-z0-9_]+):\s*(.+)$/);
    if (questionMatch && !isIndented) {
      const [, id, text] = questionMatch;
      if (!nodes[id]) {
        nodes[id] = {
          id,
          kind: 'question',
          text: text.trim(),
          input: { type: 'binary' }, // default, overwritten by first edge/route
          edges: [],
        };
        questionOrder.push(id);
      }
      currentQuestionId = id;
      currentOutcomeId = null;
      inRoutesBlock = false;
      continue;
    }

    // ── Question child attributes (indented under question) ───────
    if (isIndented && currentQuestionId) {
      const trimmed = line.trim();
      const qnode = nodes[currentQuestionId] as QuestionNode;

      // hint: text
      const hintMatch = trimmed.match(/^hint:\s*(.+)$/);
      if (hintMatch) {
        nodes[currentQuestionId] = { ...qnode, hint: hintMatch[1].trim() };
        continue;
      }

      // routes: block header (elimination mode)
      if (trimmed === 'routes:') {
        inRoutesBlock = true;
        if (!qnode.routes) {
          nodes[currentQuestionId] = { ...qnode, routes: {} };
        }
        continue;
      }

      // Route lines inside a per-question routes: block
      if (inRoutesBlock) {
        // Binary route: yes/no -> [OUT1, OUT2, ...]
        const binaryRouteMatch = trimmed.match(/^(yes|no)\s*->\s*\[([^\]]+)\]$/i);
        if (binaryRouteMatch) {
          const [, answer, outcomeList] = binaryRouteMatch;
          const answerNorm = answer.toLowerCase();
          const outcomeIds = outcomeList.split(',').map((s) => s.trim());
          const updatedQNode = nodes[currentQuestionId] as QuestionNode;
          const updatedRoutes = { ...(updatedQNode.routes ?? {}), [answerNorm]: outcomeIds };
          const isBinary = Object.keys(updatedRoutes).every((a) => a === 'yes' || a === 'no');
          nodes[currentQuestionId] = {
            ...updatedQNode,
            routes: updatedRoutes,
            input: isBinary ? { type: 'binary' } : updatedQNode.input,
          };
          continue;
        }

        // Choice route: A: Label -> [OUT1, OUT2, ...]
        const choiceRouteMatch = trimmed.match(/^([A-F]):\s*(.+?)\s*->\s*\[([^\]]+)\]$/);
        if (choiceRouteMatch) {
          const [, value, label, outcomeList] = choiceRouteMatch;
          const outcomeIds = outcomeList.split(',').map((s) => s.trim());
          const updatedQNode = nodes[currentQuestionId] as QuestionNode;
          const updatedRoutes = { ...(updatedQNode.routes ?? {}), [value]: outcomeIds };
          const prevInput = updatedQNode.input;
          const prevOptions =
            prevInput.type === 'choice' ? prevInput.options : ([] as ChoiceOption[]);
          nodes[currentQuestionId] = {
            ...updatedQNode,
            routes: updatedRoutes,
            input: { type: 'choice', options: [...prevOptions, { value, label: label.trim() }] },
          };
          continue;
        }

        // If we hit something that doesn't match a route line, exit routes block
        inRoutesBlock = false;
      }

      // Binary edge: yes -> TARGET  or  no -> TARGET
      const binaryMatch = trimmed.match(/^(yes|no)\s*->\s*\[?([A-Za-z0-9_]+)\]?$/i);
      if (binaryMatch) {
        const [, answer, next] = binaryMatch;
        const answerNorm = answer.toLowerCase();
        const updatedQNode = nodes[currentQuestionId] as QuestionNode;
        const edges = [...updatedQNode.edges, { answer: answerNorm, next }] as Edge[];
        const isBinary = edges.every((e) => e.answer === 'yes' || e.answer === 'no');
        nodes[currentQuestionId] = {
          ...updatedQNode,
          edges,
          input: isBinary ? { type: 'binary' } : updatedQNode.input,
        };
        if (!incomingEdges[next]) incomingEdges[next] = [];
        incomingEdges[next].push(currentQuestionId);
        continue;
      }

      // Choice edge: A: Label text -> TARGET
      const choiceMatch = trimmed.match(/^([A-F]):\s*(.+?)\s*->\s*\[?([A-Za-z0-9_]+)\]?$/);
      if (choiceMatch) {
        const [, value, label, next] = choiceMatch;
        const updatedQNode = nodes[currentQuestionId] as QuestionNode;
        const edges = [...updatedQNode.edges, { answer: value, label: label.trim(), next }] as Edge[];
        const options = edges.map((e) => ({ value: e.answer, label: e.label ?? e.answer }));
        nodes[currentQuestionId] = {
          ...updatedQNode,
          edges,
          input: { type: 'choice', options },
        };
        if (!incomingEdges[next]) incomingEdges[next] = [];
        incomingEdges[next].push(currentQuestionId);
        continue;
      }

      // Inline choice + route: A: Label text [OUT1, OUT2]  (no -> required)
      // Sets both the option label and the route for this answer.
      const inlineRouteMatch = trimmed.match(/^([A-F]):\s*(.+?)\s*\[([A-Za-z0-9_,\s]+)\]$/);
      if (inlineRouteMatch) {
        const [, value, label, outcomeList] = inlineRouteMatch;
        const outcomeIds = outcomeList.split(',').map((s) => s.trim()).filter(Boolean);
        const updatedQNode = nodes[currentQuestionId] as QuestionNode;
        const updatedRoutes = { ...(updatedQNode.routes ?? {}), [value]: outcomeIds };
        const prevInput = updatedQNode.input;
        const prevOptions =
          prevInput.type === 'choice' ? prevInput.options : ([] as ChoiceOption[]);
        nodes[currentQuestionId] = {
          ...updatedQNode,
          routes: updatedRoutes,
          input: { type: 'choice', options: [...prevOptions, { value, label: label.trim() }] },
        };
        continue;
      }

      // Inline choice label only: A: Label text  (no -> and no brackets)
      // Registers a labelled choice option; the question is a pass-through
      // (no routes set, so it doesn't filter outcomes).
      const inlineLabelMatch = trimmed.match(/^([A-F]):\s*(.+)$/);
      if (inlineLabelMatch) {
        const [, value, label] = inlineLabelMatch;
        const updatedQNode = nodes[currentQuestionId] as QuestionNode;
        const prevInput = updatedQNode.input;
        const prevOptions =
          prevInput.type === 'choice' ? prevInput.options : ([] as ChoiceOption[]);
        // Only add the option if it hasn't been set by a previous pattern
        if (!prevOptions.find((o) => o.value === value)) {
          nodes[currentQuestionId] = {
            ...updatedQNode,
            input: { type: 'choice', options: [...prevOptions, { value, label: label.trim() }] },
          };
        }
        continue;
      }
    }
  }

  // ── Validation ─────────────────────────────────────────────────────────

  if (!entry) throw makeError('"entry:" directive is required');
  if (!nodes[entry]) throw makeError(`Entry node "${entry}" is not defined`);
  if (nodes[entry]?.kind !== 'question') {
    throw makeError(`Entry node "${entry}" must be a question, not an outcome`);
  }

  for (const [id, node] of Object.entries(nodes)) {
    if (node.kind === 'question') {
      const hasEdges = node.edges && node.edges.length > 0;
      const hasRoutes = node.routes && Object.keys(node.routes).length > 0;
      if (hasEdges && hasRoutes) {
        throw makeError(
          `Question "${id}" defines both edges and routes. ` +
            `Use edges for decision mode or routes: for elimination mode, not both.`
        );
      }

      if (mode === 'decision') {
        if (!node.edges || node.edges.length === 0) {
          throw makeError(`Question "${id}" has no edges defined`);
        }
        for (const edge of node.edges) {
          if (!nodes[edge.next]) {
            throw makeError(
              `Question "${id}": edge answer "${edge.answer}" points to undefined node "${edge.next}"`
            );
          }
        }
      } else {
        // elimination mode — questions without a routes: block are pass-throughs
        // (they record the answer but do not filter outcomes)
        if (!node.routes || Object.keys(node.routes).length === 0) {
          if (node.edges && node.edges.length > 0) {
            throw makeError(
              `Question "${id}" in elimination mode defines edges but no routes: block. ` +
                `Use a routes: block to filter outcomes, or remove the edges.`
            );
          }
          continue; // pass-through: no validation needed
        }
        for (const [answer, outcomeIds] of Object.entries(node.routes)) {
          for (const oid of outcomeIds) {
            if (!nodes[oid]) {
              throw makeError(
                `Question "${id}": route answer "${answer}" references undefined outcome "${oid}"`
              );
            }
            if (nodes[oid].kind !== 'outcome') {
              throw makeError(
                `Question "${id}": route answer "${answer}" references "${oid}" which is not an outcome node`
              );
            }
          }
        }
      }
    }
  }

  // Cycle detection via DFS (decision mode only — elimination mode has no edges)
  if (mode === 'decision') {
    detectCycles(nodes, entry);
  }

  // ── Build result ────────────────────────────────────────────────────────

  const dag: DecisionDAG = {
    $schema_version: '1.0.0',
    id: generateUUID(),
    name: name || undefined,
    version,
    mode,
    entry,
    ...(mode === 'elimination' ? { questionOrder } : {}),
    nodes: nodes as Readonly<Record<string, DAGNode>>,
    ...(docRoutes && docRoutes.length > 0 ? { routes: docRoutes } : {}),
  };

  const sharedNodes = Object.entries(incomingEdges)
    .filter(([, parents]) => parents.length > 1)
    .map(([id]) => id);

  // In elimination mode all questions are always asked, so add every question
  // in questionOrder to reachableNodes even though they have no edges.
  const reachableBase = collectReachable(nodes, entry);
  const reachableNodes =
    mode === 'elimination'
      ? [...new Set([...reachableBase, ...questionOrder])]
      : reachableBase;

  const orphanNodes = Object.keys(nodes).filter(
    (id) => !reachableNodes.includes(id)
  );

  return { dag, sharedNodes, reachableNodes, orphanNodes };
}

// ── Graph utilities ────────────────────────────────────────────────────────

function detectCycles(nodes: Record<string, DAGNode>, entry: string): void {
  const visited = new Set<string>();
  const stack = new Set<string>();

  function dfs(id: string): void {
    if (stack.has(id)) {
      throw makeError(
        `Cycle detected — node "${id}" is reachable via itself. DAGs must be acyclic.`
      );
    }
    if (visited.has(id)) return;
    visited.add(id);
    stack.add(id);
    const node = nodes[id];
    if (node?.kind === 'question') {
      for (const edge of node.edges) {
        dfs(edge.next);
      }
    }
    stack.delete(id);
  }

  dfs(entry);
}

function collectReachable(nodes: Record<string, DAGNode>, entry: string): string[] {
  const visited = new Set<string>();
  const queue: string[] = [entry];
  while (queue.length > 0) {
    const id = queue.shift()!;
    if (visited.has(id)) continue;
    visited.add(id);
    const node = nodes[id];
    if (node?.kind === 'question') {
      for (const edge of node.edges) {
        queue.push(edge.next);
      }
      if (node.routes) {
        for (const outcomeIds of Object.values(node.routes)) {
          for (const oid of outcomeIds) queue.push(oid);
        }
      }
    }
  }
  return Array.from(visited);
}

function makeError(message: string, line?: number): ParseError {
  return { message, line };
}

// ── Depth utility (used by wizard for progress calculation) ───────────────

/**
 * Returns the maximum number of question nodes on any path from the
 * given node to any outcome. Used to calculate wizard progress.
 */
export function maxDepthFrom(dag: DecisionDAG, startId: string): number {
  const cache: Record<string, number> = {};

  function depth(id: string): number {
    if (id in cache) return cache[id];
    const node = dag.nodes[id];
    if (!node || node.kind === 'outcome') {
      cache[id] = 0;
      return 0;
    }
    const max = Math.max(...node.edges.map((e) => 1 + depth(e.next)));
    cache[id] = max;
    return max;
  }

  return depth(startId);
}

// ── Serialisation helpers ─────────────────────────────────────────────────

export function serialiseDAG(dag: DecisionDAG): string {
  return JSON.stringify(dag, null, 2);
}

export function deserialiseDAG(json: string): DecisionDAG {
  const parsed: unknown = JSON.parse(json);
  if (
    typeof parsed !== 'object' ||
    parsed === null ||
    (parsed as Record<string, unknown>)['$schema_version'] !== '1.0.0'
  ) {
    throw new Error(
      'Invalid DecisionDAG document: missing or unsupported $schema_version'
    );
  }
  return parsed as DecisionDAG;
}

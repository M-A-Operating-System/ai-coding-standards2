/**
 * decision-dag — traversal engine
 *
 * Pure functions for traversing a DecisionDAG at runtime.
 * No React, no side effects — safe to use in Edge Functions, unit tests,
 * or any framework.
 */

import type { DecisionDAG, OutcomeNode, QuestionNode } from './dag-types';
import { isQuestionNode, isOutcomeNode } from './dag-types';
import { maxDepthFrom } from './dag-parser';

// ── Wizard state ──────────────────────────────────────────────────────────

export interface WizardState {
  /** ID of the currently displayed node */
  readonly currentNodeId: string;
  /** Ordered list of previously visited question IDs (for back navigation) */
  readonly history: ReadonlyArray<string>;
  /** Map of questionId → answer value for all answered questions */
  readonly answers: Readonly<Record<string, string>>;
  /**
   * Elimination mode only: outcome IDs still in play after applying all answers so far.
   * Undefined in decision mode.
   */
  readonly remainingOutcomes?: ReadonlyArray<string>;
}

// ── Factory ───────────────────────────────────────────────────────────────

/**
 * Create the initial WizardState for a given DAG.
 */
export function initWizard(dag: DecisionDAG): WizardState {
  if (dag.mode === 'elimination') {
    const allOutcomes = Object.values(dag.nodes)
      .filter((n) => n.kind === 'outcome')
      .map((n) => n.id);
    return {
      currentNodeId: dag.entry,
      history: [],
      answers: {},
      remainingOutcomes: allOutcomes,
    };
  }
  return {
    currentNodeId: dag.entry,
    history: [],
    answers: {},
  };
}

// ── Elimination mode helpers ──────────────────────────────────────────────

/**
 * Recompute remaining outcomes from scratch by replaying all answers.
 * Used by goBack in elimination mode to restore correct state.
 */
function computeRemainingOutcomes(
  dag: DecisionDAG,
  answers: Readonly<Record<string, string>>
): string[] {
  const allOutcomes = Object.values(dag.nodes)
    .filter((n) => n.kind === 'outcome')
    .map((n) => n.id);

  let remaining = new Set(allOutcomes);

  for (const [questionId, answer] of Object.entries(answers)) {
    const node = dag.nodes[questionId];
    if (node?.kind === 'question' && node.routes) {
      const kept = node.routes[answer];
      if (kept) {
        remaining = new Set(kept.filter((id) => remaining.has(id)));
      }
    }
  }
  return Array.from(remaining);
}

/**
 * Find the next question to ask in elimination mode.
 * Returns the first question in questionOrder that hasn't been answered yet,
 * or null if all questions have been answered.
 */
function nextEliminationQuestion(
  dag: DecisionDAG,
  answers: Readonly<Record<string, string>>
): string | null {
  const order = dag.questionOrder ?? [];
  for (const id of order) {
    if (!(id in answers)) return id;
  }
  return null;
}

// ── Navigation ────────────────────────────────────────────────────────────

/**
 * Advance the wizard by recording the user's answer and moving to the next node.
 * Returns a new WizardState — does not mutate the input.
 *
 * @throws if the current node is an outcome (cannot advance from a terminal node)
 * @throws if the answer does not match any edge/route on the current node
 */
export function advance(
  dag: DecisionDAG,
  state: WizardState,
  answer: string
): WizardState {
  const node = dag.nodes[state.currentNodeId];

  if (!node) {
    throw new Error(`Node "${state.currentNodeId}" does not exist in the DAG`);
  }
  if (isOutcomeNode(node)) {
    throw new Error(
      `Cannot advance from outcome node "${state.currentNodeId}"`
    );
  }

  // Hoist shared state so both branches and the return can use them
  const newAnswers = { ...state.answers, [state.currentNodeId]: answer };
  const newHistory = [...state.history, state.currentNodeId];

  if (dag.mode === 'elimination') {
    const isPassThrough = !node.routes || Object.keys(node.routes).length === 0;

    // Validate answer against per-question routes (pass-throughs accept any answer)
    if (!isPassThrough && !Object.hasOwn(node.routes!, answer)) {
      const valid = Object.keys(node.routes!).join(', ');
      throw new Error(
        `No route with answer "${answer}" on node "${state.currentNodeId}". ` +
          `Valid answers: ${valid}`
      );
    }

    // Intersect remaining outcomes; pass-throughs leave the set unchanged
    const newRemaining = isPassThrough
      ? [...(state.remainingOutcomes ?? [])]
      : (() => {
          const outcomeIds = node.routes![answer];
          const kept = new Set(Array.isArray(outcomeIds) ? outcomeIds : []);
          return (state.remainingOutcomes ?? []).filter((id) => kept.has(id));
        })();

    // Find the next question or resolve to an outcome
    const nextQuestionId = nextEliminationQuestion(dag, newAnswers);
    if (nextQuestionId && newRemaining.length > 1) {
      return {
        currentNodeId: nextQuestionId,
        history: newHistory,
        answers: newAnswers,
        remainingOutcomes: newRemaining,
      };
    }

    // All questions answered or narrowed to one outcome — resolve
    const winnerId =
      newRemaining[0] ??
      Object.keys(dag.nodes).find((id) => dag.nodes[id].kind === 'outcome') ??
      state.currentNodeId;

    return {
      currentNodeId: winnerId,
      history: newHistory,
      answers: newAnswers,
      remainingOutcomes: newRemaining,
    };
  }

  // decision mode — check document-level explicit routes first
  if (dag.routes && dag.routes.length > 0) {
    for (const route of dag.routes) {
      const match = route.path.every((step) => {
        const ans = newAnswers[step.question];
        return ans !== undefined && step.answers.includes(ans);
      });
      if (match) {
        return {
          currentNodeId: route.outcomeId,
          history: newHistory,
          answers: newAnswers,
        };
      }
    }
  }

  // Normal DAG edge traversal
  const edge = node.edges.find((e) => e.answer === answer);
  if (!edge) {
    throw new Error(
      `No edge with answer "${answer}" on node "${state.currentNodeId}". ` +
        `Valid answers: ${node.edges.map((e) => e.answer).join(', ')}`
    );
  }

  return {
    currentNodeId: edge.next,
    history: newHistory,
    answers: newAnswers,
  };
}

/**
 * Navigate back to the previous question.
 * Returns a new WizardState — does not mutate the input.
 *
 * @throws if there is no history to go back to
 */
export function goBack(
  dag: DecisionDAG,
  state: WizardState
): WizardState {
  if (state.history.length === 0) {
    throw new Error('Cannot go back: no history recorded');
  }

  const history = [...state.history];
  const previousNodeId = history.pop()!;

  const answers = { ...state.answers };
  delete answers[previousNodeId];

  if (dag.mode === 'elimination') {
    // Recompute remaining outcomes from the rolled-back answers
    const newRemaining = computeRemainingOutcomes(dag, answers);
    return {
      currentNodeId: previousNodeId,
      history,
      answers,
      remainingOutcomes: newRemaining,
    };
  }

  return {
    currentNodeId: previousNodeId,
    history,
    answers,
  };
}

/**
 * Reset the wizard to its starting state.
 */
export function resetWizard(dag: DecisionDAG): WizardState {
  return initWizard(dag);
}

// ── Derived state ─────────────────────────────────────────────────────────

export type WizardPhase = 'answering' | 'complete';

/**
 * Returns the current phase of the wizard.
 * In elimination mode the wizard is complete when:
 *   - currentNodeId points to an outcome node (single winner), OR
 *   - there are no more questions to ask (all answered, even with tied outcomes)
 */
export function getPhase(dag: DecisionDAG, state: WizardState): WizardPhase {
  const node = dag.nodes[state.currentNodeId];
  if (node && isOutcomeNode(node)) return 'complete';
  if (dag.mode === 'elimination') {
    const nextQuestion = nextEliminationQuestion(dag, state.answers);
    if (!nextQuestion) return 'complete';
  }
  return 'answering';
}

/**
 * Returns the current QuestionNode, or null if the wizard is complete.
 */
export function getCurrentQuestion(
  dag: DecisionDAG,
  state: WizardState
): QuestionNode | null {
  const node = dag.nodes[state.currentNodeId];
  return node && isQuestionNode(node) ? node : null;
}

/**
 * Returns the resolved OutcomeNode if complete, or null if still answering.
 */
export function getCurrentOutcome(
  dag: DecisionDAG,
  state: WizardState
): OutcomeNode | null {
  const node = dag.nodes[state.currentNodeId];
  return node && isOutcomeNode(node) ? node : null;
}

/**
 * Returns a 0–1 progress value suitable for a progress bar.
 * Elimination mode uses questions answered / total questions.
 * Decision mode uses max path depth estimate.
 */
export function getProgress(dag: DecisionDAG, state: WizardState): number {
  if (getPhase(dag, state) === 'complete') return 1;
  if (dag.mode === 'elimination') {
    const total = dag.questionOrder?.length ?? 1;
    return Math.min(state.history.length / total, 0.97);
  }
  const totalDepth = maxDepthFrom(dag, dag.entry);
  if (totalDepth === 0) return 0;
  return Math.min(state.history.length / totalDepth, 0.97);
}

/**
 * Returns a structured answer trail — the full path taken through the DAG.
 * Suitable for display on the result screen.
 */
export interface AnswerTrailEntry {
  readonly questionId: string;
  readonly questionText: string;
  readonly answerValue: string;
  readonly answerLabel: string;
}

export function getAnswerTrail(
  dag: DecisionDAG,
  state: WizardState
): ReadonlyArray<AnswerTrailEntry> {
  return state.history.map((questionId) => {
    const node = dag.nodes[questionId];
    const answerValue = state.answers[questionId] ?? '';
    let answerLabel = answerValue;

    if (node && isQuestionNode(node) && node.input.type === 'choice') {
      const opt = node.input.options.find((o) => o.value === answerValue);
      if (opt) answerLabel = `${opt.value}: ${opt.label}`;
    }

    return {
      questionId,
      questionText: node && isQuestionNode(node) ? node.text : questionId,
      answerValue,
      answerLabel,
    };
  });
}

/**
 * Enumerate all possible outcomes reachable from the current state.
 * In elimination mode, returns only the outcomes still in play.
 * In decision mode, traverses edges from the current node.
 */
export function getReachableOutcomes(
  dag: DecisionDAG,
  state: WizardState
): ReadonlyArray<OutcomeNode> {
  if (dag.mode === 'elimination') {
    const ids = state.remainingOutcomes ?? [];
    return ids
      .map((id) => dag.nodes[id])
      .filter((n): n is OutcomeNode => n?.kind === 'outcome');
  }

  const reachable = new Set<string>();
  const queue: string[] = [state.currentNodeId];

  while (queue.length > 0) {
    const id = queue.shift()!;
    if (reachable.has(id)) continue;
    reachable.add(id);
    const node = dag.nodes[id];
    if (node?.kind === 'question') {
      for (const edge of node.edges) {
        queue.push(edge.next);
      }
    }
  }

  return Array.from(reachable)
    .map((id) => dag.nodes[id])
    .filter((n): n is OutcomeNode => n?.kind === 'outcome');
}

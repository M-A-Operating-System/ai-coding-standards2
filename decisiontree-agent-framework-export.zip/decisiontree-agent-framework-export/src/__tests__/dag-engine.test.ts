import { describe, it, expect } from 'vitest';
import { parseDSL } from '../lib/dag-parser';
import {
  initWizard,
  advance,
  goBack,
  resetWizard,
  getPhase,
  getProgress,
  getCurrentQuestion,
  getCurrentOutcome,
  getReachableOutcomes,
  getAnswerTrail,
} from '../lib/dag-engine';
import type { DecisionDAG } from '../lib/dag-types';

// ── Fixtures ──────────────────────────────────────────────────────────────

function decisionDag(): DecisionDAG {
  return parseDSL(`
dag: product-fit
mode: decision
entry: Q1

Q1: Commercial?
  yes -> Q2
  no  -> [OUT_PERSONAL]

Q2: Team size?
  A: Solo  -> [OUT_PRO]
  B: Small -> [OUT_PRO]
  C: Large -> [OUT_ENTERPRISE]

[OUT_PRO]:        Pro plan
  code: PLAN_PRO
[OUT_ENTERPRISE]: Enterprise plan
  code: PLAN_ENT
[OUT_PERSONAL]:   Personal plan
  code: PLAN_FREE
`.trim()).dag;
}

function eliminationDag(): DecisionDAG {
  return parseDSL(`
dag: plan-selector
mode: elimination
entry: Q1

Q1: Commercial?
  routes:
    yes -> [OUT_PRO, OUT_TEAM, OUT_ENTERPRISE]
    no  -> [OUT_NONPROFIT, OUT_PERSONAL]

Q2: Collaboration needed?
  routes:
    yes -> [OUT_TEAM, OUT_ENTERPRISE]
    no  -> [OUT_PRO, OUT_NONPROFIT, OUT_PERSONAL]

Q3: Need SSO?
  routes:
    yes -> [OUT_ENTERPRISE]
    no  -> [OUT_PRO, OUT_TEAM, OUT_NONPROFIT, OUT_PERSONAL]

[OUT_PRO]:        Pro
[OUT_TEAM]:       Team
[OUT_ENTERPRISE]: Enterprise
[OUT_NONPROFIT]:  Nonprofit
[OUT_PERSONAL]:   Personal
`.trim()).dag;
}

// ── initWizard ────────────────────────────────────────────────────────────

describe('initWizard', () => {
  it('decision mode: starts at entry, empty history and answers', () => {
    const dag = decisionDag();
    const state = initWizard(dag);
    expect(state.currentNodeId).toBe('Q1');
    expect(state.history).toHaveLength(0);
    expect(state.answers).toEqual({});
    expect(state.remainingOutcomes).toBeUndefined();
  });

  it('elimination mode: initialises remainingOutcomes with all outcomes', () => {
    const dag = eliminationDag();
    const state = initWizard(dag);
    expect(state.remainingOutcomes).toBeDefined();
    expect(state.remainingOutcomes).toHaveLength(5);
    expect(state.remainingOutcomes).toContain('OUT_PRO');
    expect(state.remainingOutcomes).toContain('OUT_NONPROFIT');
  });
});

// ── advance — decision mode ───────────────────────────────────────────────

describe('advance — decision mode', () => {
  it('follows a binary edge', () => {
    const dag = decisionDag();
    const s1 = advance(dag, initWizard(dag), 'yes');
    expect(s1.currentNodeId).toBe('Q2');
    expect(s1.history).toEqual(['Q1']);
    expect(s1.answers).toEqual({ Q1: 'yes' });
  });

  it('follows a choice edge', () => {
    const dag = decisionDag();
    const s1 = advance(dag, initWizard(dag), 'yes');
    const s2 = advance(dag, s1, 'C');
    expect(s2.currentNodeId).toBe('OUT_ENTERPRISE');
  });

  it('reaches outcome and phase becomes complete', () => {
    const dag = decisionDag();
    let state = initWizard(dag);
    state = advance(dag, state, 'no');
    expect(getPhase(dag, state)).toBe('complete');
    expect(getCurrentOutcome(dag, state)?.id).toBe('OUT_PERSONAL');
  });

  it('throws on unknown answer', () => {
    const dag = decisionDag();
    expect(() => advance(dag, initWizard(dag), 'maybe')).toThrow('No edge with answer');
  });

  it('throws when advancing from an outcome node', () => {
    const dag = decisionDag();
    let state = initWizard(dag);
    state = advance(dag, state, 'no'); // → OUT_PERSONAL
    expect(() => advance(dag, state, 'yes')).toThrow('Cannot advance from outcome node');
  });

  it('document-level route shortcut fires before edge traversal', () => {
    const dsl = `
dag: d
entry: Q1
Q1: Commercial?
  yes -> Q2
  no  -> [OUT_PERSONAL]
Q2: Large?
  yes -> [OUT_ENTERPRISE]
  no  -> [OUT_PRO]
[OUT_PERSONAL]: Personal
[OUT_ENTERPRISE]: Enterprise
[OUT_PRO]: Pro

routes:
  Q1=yes, Q2=no -> [OUT_ENTERPRISE]
`.trim();
    const dag = parseDSL(dsl).dag;
    let state = initWizard(dag);
    state = advance(dag, state, 'yes'); // Q1=yes
    state = advance(dag, state, 'no');  // Q2=no — matches route → OUT_ENTERPRISE
    expect(state.currentNodeId).toBe('OUT_ENTERPRISE');
  });
});

// ── advance — elimination mode ────────────────────────────────────────────

describe('advance — elimination mode', () => {
  it('intersects remainingOutcomes with route kept set', () => {
    const dag = eliminationDag();
    const s1 = advance(dag, initWizard(dag), 'yes');
    expect(s1.remainingOutcomes).toEqual(
      expect.arrayContaining(['OUT_PRO', 'OUT_TEAM', 'OUT_ENTERPRISE'])
    );
    expect(s1.remainingOutcomes).not.toContain('OUT_PERSONAL');
    expect(s1.remainingOutcomes).not.toContain('OUT_NONPROFIT');
  });

  it('moves to next question in questionOrder', () => {
    const dag = eliminationDag();
    const s1 = advance(dag, initWizard(dag), 'yes');
    expect(s1.currentNodeId).toBe('Q2');
  });

  it('narrows to single outcome and completes', () => {
    const dag = eliminationDag();
    let state = initWizard(dag);
    state = advance(dag, state, 'yes');   // Q1=yes → PRO, TEAM, ENT
    state = advance(dag, state, 'yes');   // Q2=yes → TEAM, ENT
    state = advance(dag, state, 'yes');   // Q3=yes → ENT
    expect(getPhase(dag, state)).toBe('complete');
    expect(state.remainingOutcomes).toEqual(['OUT_ENTERPRISE']);
  });

  it('completes when all questions answered even with ties', () => {
    const dag = eliminationDag();
    let state = initWizard(dag);
    state = advance(dag, state, 'yes');  // Q1=yes → PRO, TEAM, ENT
    state = advance(dag, state, 'yes');  // Q2=yes → TEAM, ENT (2 remain)
    state = advance(dag, state, 'no');   // Q3=no  → PRO, TEAM, NONPROFIT, PERSONAL ∩ {TEAM,ENT} = TEAM
    expect(getPhase(dag, state)).toBe('complete');
    expect(state.remainingOutcomes).toContain('OUT_TEAM');
  });

  it('throws on unknown answer', () => {
    const dag = eliminationDag();
    expect(() => advance(dag, initWizard(dag), 'maybe')).toThrow('No route with answer');
  });

  it('pass-through question does not filter remaining outcomes', () => {
    // Build a dag with a pass-through question (no routes)
    const dag = parseDSL(`
dag: d
mode: elimination
entry: Q1
Q1: Filter?
  routes:
    yes -> [OUT_A, OUT_B]
    no  -> [OUT_B]
Q2: Context only?
[OUT_A]: A
[OUT_B]: B
`.trim()).dag;
    let state = initWizard(dag);
    state = advance(dag, state, 'yes'); // Q1=yes → [OUT_A, OUT_B]
    expect(state.remainingOutcomes).toEqual(expect.arrayContaining(['OUT_A', 'OUT_B']));
    expect(state.remainingOutcomes).toHaveLength(2);
    // Q2 is a pass-through — remaining should be unchanged
    state = advance(dag, state, 'yes');
    expect(state.remainingOutcomes).toEqual(expect.arrayContaining(['OUT_A', 'OUT_B']));
    expect(state.remainingOutcomes).toHaveLength(2);
    expect(state.answers['Q2']).toBe('yes');
  });

  it('goBack over pass-through question restores remaining outcomes', () => {
    const dag = parseDSL(`
dag: d
mode: elimination
entry: Q1
Q1: Filter?
  routes:
    yes -> [OUT_A, OUT_B]
    no  -> [OUT_B]
Q2: Context only?
[OUT_A]: A
[OUT_B]: B
`.trim()).dag;
    let state = initWizard(dag);
    state = advance(dag, state, 'yes'); // Q1=yes → [OUT_A, OUT_B]
    state = advance(dag, state, 'no');  // Q2 pass-through
    state = goBack(dag, state);
    expect(state.answers['Q2']).toBeUndefined();
    expect(state.remainingOutcomes).toEqual(expect.arrayContaining(['OUT_A', 'OUT_B']));
  });
});

// ── goBack ────────────────────────────────────────────────────────────────

describe('goBack', () => {
  it('decision mode: returns to previous question and removes answer', () => {
    const dag = decisionDag();
    let state = initWizard(dag);
    state = advance(dag, state, 'yes'); // Q1→Q2
    state = goBack(dag, state);
    expect(state.currentNodeId).toBe('Q1');
    expect(state.answers['Q1']).toBeUndefined();
    expect(state.history).toHaveLength(0);
  });

  it('throws when no history', () => {
    const dag = decisionDag();
    expect(() => goBack(dag, initWizard(dag))).toThrow('no history recorded');
  });

  it('elimination mode: recomputes remainingOutcomes correctly on back', () => {
    const dag = eliminationDag();
    let state = initWizard(dag);
    state = advance(dag, state, 'yes'); // Q1=yes → 3 remain
    state = advance(dag, state, 'yes'); // Q2=yes → 2 remain
    state = goBack(dag, state);         // undo Q2 → back to 3
    expect(state.currentNodeId).toBe('Q2');
    expect(state.remainingOutcomes).toHaveLength(3);
    expect(state.remainingOutcomes).toContain('OUT_PRO');
  });

  it('elimination mode: going back to start restores all outcomes', () => {
    const dag = eliminationDag();
    let state = initWizard(dag);
    state = advance(dag, state, 'yes');
    state = goBack(dag, state);
    expect(state.remainingOutcomes).toHaveLength(5);
  });
});

// ── resetWizard ───────────────────────────────────────────────────────────

describe('resetWizard', () => {
  it('returns to initial state', () => {
    const dag = decisionDag();
    let state = initWizard(dag);
    state = advance(dag, state, 'yes');
    state = resetWizard(dag);
    expect(state).toEqual(initWizard(dag));
  });
});

// ── getProgress ───────────────────────────────────────────────────────────

describe('getProgress', () => {
  it('decision mode: 0 at start, 1 at outcome', () => {
    const dag = decisionDag();
    expect(getProgress(dag, initWizard(dag))).toBe(0);
    const complete = advance(dag, initWizard(dag), 'no');
    expect(getProgress(dag, complete)).toBe(1);
  });

  it('elimination mode: proportional to questions answered', () => {
    const dag = eliminationDag(); // 3 questions
    const s0 = initWizard(dag);
    const s1 = advance(dag, s0, 'yes');
    const s2 = advance(dag, s1, 'yes');
    expect(getProgress(dag, s0)).toBeCloseTo(0);
    expect(getProgress(dag, s1)).toBeCloseTo(1 / 3);
    expect(getProgress(dag, s2)).toBeCloseTo(2 / 3);
  });
});

// ── getReachableOutcomes ──────────────────────────────────────────────────

describe('getReachableOutcomes', () => {
  it('decision mode: returns outcomes reachable from current node', () => {
    const dag = decisionDag();
    const state = initWizard(dag);
    const outcomes = getReachableOutcomes(dag, state);
    const ids = outcomes.map((o) => o.id);
    expect(ids).toContain('OUT_PRO');
    expect(ids).toContain('OUT_ENTERPRISE');
    expect(ids).toContain('OUT_PERSONAL');
  });

  it('decision mode: narrows after answering', () => {
    const dag = decisionDag();
    const state = advance(dag, initWizard(dag), 'yes'); // no path to PERSONAL
    const ids = getReachableOutcomes(dag, state).map((o) => o.id);
    expect(ids).not.toContain('OUT_PERSONAL');
    expect(ids).toContain('OUT_PRO');
  });

  it('elimination mode: returns remainingOutcomes as OutcomeNodes', () => {
    const dag = eliminationDag();
    const s1 = advance(dag, initWizard(dag), 'yes');
    const outcomes = getReachableOutcomes(dag, s1);
    expect(outcomes).toHaveLength(3);
    expect(outcomes.map((o) => o.id)).toContain('OUT_ENTERPRISE');
  });
});

// ── getAnswerTrail ────────────────────────────────────────────────────────

describe('getAnswerTrail', () => {
  it('returns empty trail at start', () => {
    const dag = decisionDag();
    expect(getAnswerTrail(dag, initWizard(dag))).toHaveLength(0);
  });

  it('records question text and answer label', () => {
    const dag = decisionDag();
    let state = initWizard(dag);
    state = advance(dag, state, 'yes');
    state = advance(dag, state, 'A');
    const trail = getAnswerTrail(dag, state);
    expect(trail).toHaveLength(2);
    expect(trail[0].questionText).toContain('Commercial');
    expect(trail[0].answerValue).toBe('yes');
    expect(trail[1].answerLabel).toContain('Solo');
  });
});

// ── getCurrentQuestion / getCurrentOutcome ────────────────────────────────

describe('getCurrentQuestion / getCurrentOutcome', () => {
  it('getCurrentQuestion returns node while answering', () => {
    const dag = decisionDag();
    const q = getCurrentQuestion(dag, initWizard(dag));
    expect(q).not.toBeNull();
    expect(q!.id).toBe('Q1');
  });

  it('getCurrentOutcome returns null while answering', () => {
    const dag = decisionDag();
    expect(getCurrentOutcome(dag, initWizard(dag))).toBeNull();
  });

  it('getCurrentOutcome returns node when complete', () => {
    const dag = decisionDag();
    const state = advance(dag, initWizard(dag), 'no');
    expect(getCurrentOutcome(dag, state)?.id).toBe('OUT_PERSONAL');
    expect(getCurrentQuestion(dag, state)).toBeNull();
  });
});

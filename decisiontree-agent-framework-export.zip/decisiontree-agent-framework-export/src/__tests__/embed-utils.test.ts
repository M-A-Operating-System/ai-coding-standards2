import { describe, it, expect } from 'vitest';
import { encodeDsl, decodeDsl, buildEmbedUrl } from '../lib/embed-utils';

describe('encodeDsl / decodeDsl', () => {
  it('round-trips ASCII text', () => {
    const dsl = 'dag: test\nentry: Q1\nQ1: Hello?';
    expect(decodeDsl(encodeDsl(dsl))).toBe(dsl);
  });

  it('round-trips Unicode text', () => {
    const dsl = 'dag: 测试\nentry: Q1\nQ1: Is this a question? 日本語 émoji 🚀';
    expect(decodeDsl(encodeDsl(dsl))).toBe(dsl);
  });

  it('produces URL-safe output (no +, /, or = characters)', () => {
    // Run many strings through the encoder to exercise different padding cases
    for (const dsl of ['a', 'ab', 'abc', 'abcd', 'Hello, World!', 'dag: foo\nversion: 1.0.0']) {
      const token = encodeDsl(dsl);
      expect(token).not.toMatch(/[+/=]/);
    }
  });

  it('decodes tokens that had padding stripped (length % 4 != 0)', () => {
    // Explicitly strip padding and verify decoding still works
    const dsl = 'Hello!';
    const token = encodeDsl(dsl);
    // Verify the token itself decodes correctly regardless of its length mod 4
    expect(decodeDsl(token)).toBe(dsl);
  });

  it('handles an empty string', () => {
    expect(decodeDsl(encodeDsl(''))).toBe('');
  });
});

describe('buildEmbedUrl', () => {
  it('builds a correct URL with dsl param', () => {
    const url = buildEmbedUrl('https://example.com', 'abc123');
    expect(url).toBe('https://example.com/embed?dsl=abc123');
  });

  it('handles a baseUrl with a trailing slash', () => {
    const url = buildEmbedUrl('https://example.com/', 'abc123');
    expect(url).toBe('https://example.com/embed?dsl=abc123');
  });

  it('does not double-encode the dsl token', () => {
    const token = encodeDsl('dag: test');
    const url = buildEmbedUrl('https://example.com', token);
    const parsed = new URL(url);
    expect(parsed.searchParams.get('dsl')).toBe(token);
  });
});

import { describe, it, expect } from 'vitest';
import { parseDSL } from '../lib/dag-parser';

// ── Helpers ───────────────────────────────────────────────────────────────

function parse(dsl: string) {
  return parseDSL(dsl);
}

function expectParseError(dsl: string, fragment: string) {
  expect(() => parse(dsl)).toThrow(fragment);
}

// ── Decision mode ─────────────────────────────────────────────────────────

describe('parseDSL — decision mode', () => {
  const SIMPLE = `
dag: simple
version: 1.0.0
entry: Q1

Q1: Are you a developer?
  yes -> [OUT_YES]
  no  -> [OUT_NO]

[OUT_YES]: Developer
[OUT_NO]:  Non-developer
`.trim();

  it('parses a minimal binary-edge DAG', () => {
    const { dag } = parse(SIMPLE);
    expect(dag.name).toBe('simple');
    expect(dag.version).toBe('1.0.0');
    expect(dag.entry).toBe('Q1');
    expect(dag.mode).toBe('decision');
    expect(Object.keys(dag.nodes)).toHaveLength(3);
  });

  it('sets node kinds correctly', () => {
    const { dag } = parse(SIMPLE);
    expect(dag.nodes['Q1'].kind).toBe('question');
    expect(dag.nodes['OUT_YES'].kind).toBe('outcome');
    expect(dag.nodes['OUT_NO'].kind).toBe('outcome');
  });

  it('parses binary edges onto question node', () => {
    const { dag } = parse(SIMPLE);
    const q = dag.nodes['Q1'];
    if (q.kind !== 'question') throw new Error('expected question');
    expect(q.edges).toHaveLength(2);
    expect(q.edges[0]).toMatchObject({ answer: 'yes', next: 'OUT_YES' });
    expect(q.edges[1]).toMatchObject({ answer: 'no', next: 'OUT_NO' });
    expect(q.input.type).toBe('binary');
  });

  it('parses outcome label and optional fields', () => {
    const dsl = `
dag: d
entry: Q1
Q1: Q?
  yes -> [OUT_A]
  no  -> [OUT_B]
[OUT_A]: Alpha
  description: The alpha outcome
  code: ALPHA
[OUT_B]: Beta
`.trim();
    const { dag } = parse(dsl);
    const a = dag.nodes['OUT_A'];
    if (a.kind !== 'outcome') throw new Error();
    expect(a.label).toBe('Alpha');
    expect(a.description).toBe('The alpha outcome');
    expect(a.code).toBe('ALPHA');
    const b = dag.nodes['OUT_B'];
    if (b.kind !== 'outcome') throw new Error();
    expect(b.description).toBeUndefined();
  });

  it('parses choice edges and builds options array', () => {
    const dsl = `
dag: d
entry: Q1
Q1: Pick one
  A: Option Alpha -> [OUT_A]
  B: Option Beta  -> [OUT_B]
  C: Option Gamma -> [OUT_C]
[OUT_A]: A
[OUT_B]: B
[OUT_C]: C
`.trim();
    const { dag } = parse(dsl);
    const q = dag.nodes['Q1'];
    if (q.kind !== 'question') throw new Error();
    expect(q.input.type).toBe('choice');
    if (q.input.type !== 'choice') throw new Error();
    expect(q.input.options).toHaveLength(3);
    expect(q.input.options[1]).toMatchObject({ value: 'B', label: 'Option Beta' });
    expect(q.edges[2]).toMatchObject({ answer: 'C', next: 'OUT_C' });
  });

  it('parses hint on a question node', () => {
    const dsl = `
dag: d
entry: Q1
Q1: Q?
  hint: This is a helpful hint
  yes -> [OUT_A]
  no  -> [OUT_B]
[OUT_A]: A
[OUT_B]: B
`.trim();
    const { dag } = parse(dsl);
    const q = dag.nodes['Q1'];
    if (q.kind !== 'question') throw new Error();
    expect(q.hint).toBe('This is a helpful hint');
  });

  it('detects shared (multi-parent) nodes', () => {
    const dsl = `
dag: d
entry: Q1
Q1: First?
  yes -> Q2
  no  -> Q2
Q2: Shared
  yes -> [OUT_A]
  no  -> [OUT_B]
[OUT_A]: A
[OUT_B]: B
`.trim();
    const { sharedNodes } = parse(dsl);
    expect(sharedNodes).toContain('Q2');
  });

  it('detects orphan nodes', () => {
    const dsl = `
dag: d
entry: Q1
Q1: Q?
  yes -> [OUT_A]
  no  -> [OUT_B]
[OUT_A]: A
[OUT_B]: B
[OUT_ORPHAN]: Never referenced
`.trim();
    const { orphanNodes } = parse(dsl);
    expect(orphanNodes).toContain('OUT_ORPHAN');
  });

  it('throws on missing entry directive', () => {
    expectParseError('dag: d\nQ1: Q?\n  yes -> [OUT_A]\n[OUT_A]: A', '"entry:" directive is required');
  });

  it('throws when entry node is undefined', () => {
    expectParseError('dag: d\nentry: MISSING\nQ1: Q?\n  yes -> [OUT_A]\n[OUT_A]: A', '"MISSING" is not defined');
  });

  it('throws when entry is an outcome node', () => {
    const dsl = 'dag: d\nentry: OUT_A\nQ1: Q?\n  yes -> [OUT_A]\n[OUT_A]: A';
    expectParseError(dsl, 'must be a question');
  });

  it('throws on duplicate node ID', () => {
    const dsl = `
dag: d
entry: Q1
Q1: Q?
  yes -> [OUT_A]
  no  -> [OUT_B]
[OUT_A]: A
[OUT_A]: A again
`.trim();
    expectParseError(dsl, 'Duplicate node ID');
  });

  it('throws on edge pointing to undefined node', () => {
    const dsl = 'dag: d\nentry: Q1\nQ1: Q?\n  yes -> [GHOST]\n  no  -> [OUT_A]\n[OUT_A]: A';
    expectParseError(dsl, 'undefined node "GHOST"');
  });

  it('throws on question with no edges', () => {
    const dsl = `
dag: d
entry: Q1
Q1: Q?
Q2: Never connected?
  yes -> [OUT_A]
  no  -> [OUT_B]
[OUT_A]: A
[OUT_B]: B
`.trim();
    expectParseError(dsl, 'has no edges defined');
  });

  it('detects simple cycle', () => {
    const dsl = `
dag: d
entry: Q1
Q1: Loop?
  yes -> Q2
  no  -> [OUT_A]
Q2: Back?
  yes -> Q1
  no  -> [OUT_A]
[OUT_A]: A
`.trim();
    expectParseError(dsl, 'Cycle detected');
  });

  it('defaults mode to decision when omitted', () => {
    const { dag } = parse(SIMPLE);
    expect(dag.mode).toBe('decision');
  });

  it('parses document-level routes section', () => {
    const dsl = `
dag: d
entry: Q1
Q1: Commercial?
  yes -> Q2
  no  -> [OUT_PERSONAL]
Q2: Large?
  yes -> [OUT_ENTERPRISE]
  no  -> [OUT_PRO]
[OUT_PERSONAL]: Personal
[OUT_ENTERPRISE]: Enterprise
[OUT_PRO]: Pro

routes:
  Q1=yes, Q2=yes -> [OUT_ENTERPRISE]
`.trim();
    const { dag } = parse(dsl);
    expect(dag.routes).toBeDefined();
    expect(dag.routes).toHaveLength(1);
    expect(dag.routes![0].outcomeId).toBe('OUT_ENTERPRISE');
    expect(dag.routes![0].path).toMatchObject([
      { question: 'Q1', answers: ['yes'] },
      { question: 'Q2', answers: ['yes'] },
    ]);
  });
});

// ── Elimination mode ──────────────────────────────────────────────────────

describe('parseDSL — elimination mode', () => {
  const ELIM = `
dag: plan-selector
mode: elimination
version: 1.0.0
entry: Q1

Q1: Commercial org?
  routes:
    yes -> [OUT_PRO, OUT_TEAM, OUT_ENTERPRISE]
    no  -> [OUT_NONPROFIT, OUT_PERSONAL]

Q2: Team size?
  routes:
    A: Solo      -> [OUT_PRO, OUT_PERSONAL]
    B: Small     -> [OUT_PRO, OUT_TEAM]
    C: Medium    -> [OUT_TEAM, OUT_ENTERPRISE]
    D: Large     -> [OUT_ENTERPRISE]

[OUT_PRO]:        Pro
[OUT_TEAM]:       Team
[OUT_ENTERPRISE]: Enterprise
[OUT_NONPROFIT]:  Nonprofit
[OUT_PERSONAL]:   Personal
`.trim();

  it('parses mode: elimination', () => {
    const { dag } = parse(ELIM);
    expect(dag.mode).toBe('elimination');
  });

  it('records questionOrder in definition order', () => {
    const { dag } = parse(ELIM);
    expect(dag.questionOrder).toEqual(['Q1', 'Q2']);
  });

  it('parses binary routes onto question node', () => {
    const { dag } = parse(ELIM);
    const q = dag.nodes['Q1'];
    if (q.kind !== 'question') throw new Error();
    expect(q.routes).toBeDefined();
    expect(q.routes!['yes']).toEqual(['OUT_PRO', 'OUT_TEAM', 'OUT_ENTERPRISE']);
    expect(q.routes!['no']).toEqual(['OUT_NONPROFIT', 'OUT_PERSONAL']);
    expect(q.input.type).toBe('binary');
  });

  it('parses choice routes and builds options', () => {
    const { dag } = parse(ELIM);
    const q = dag.nodes['Q2'];
    if (q.kind !== 'question') throw new Error();
    expect(q.routes!['A']).toEqual(['OUT_PRO', 'OUT_PERSONAL']);
    expect(q.routes!['D']).toEqual(['OUT_ENTERPRISE']);
    expect(q.input.type).toBe('choice');
    if (q.input.type !== 'choice') throw new Error();
    expect(q.input.options).toHaveLength(4);
    expect(q.input.options[2]).toMatchObject({ value: 'C', label: 'Medium' });
  });

  it('does not set edges on elimination questions', () => {
    const { dag } = parse(ELIM);
    const q = dag.nodes['Q1'];
    if (q.kind !== 'question') throw new Error();
    expect(q.edges).toHaveLength(0);
  });

  it('question without routes parses as a pass-through (no error)', () => {
    // Pass-through: records the answer but does not filter outcomes
    const dsl = `
dag: d
mode: elimination
entry: Q1
Q1: Q?
  routes:
    yes -> [OUT_A, OUT_B]
    no  -> [OUT_B]
Q2: Context only?
[OUT_A]: A
[OUT_B]: B
`.trim();
    const { dag } = parse(dsl);
    const q2 = dag.nodes['Q2'];
    expect(q2.kind).toBe('question');
    if (q2.kind !== 'question') throw new Error();
    expect(q2.routes).toBeUndefined();
  });

  it('throws when route references undefined outcome', () => {
    const dsl = `
dag: d
mode: elimination
entry: Q1
Q1: Q?
  routes:
    yes -> [OUT_A, GHOST]
    no  -> [OUT_B]
[OUT_A]: A
[OUT_B]: B
`.trim();
    expectParseError(dsl, 'undefined outcome "GHOST"');
  });

  it('throws when route references a non-outcome node', () => {
    const dsl = `
dag: d
mode: elimination
entry: Q1
Q1: Q?
  routes:
    yes -> [Q1]
    no  -> [OUT_B]
[OUT_B]: B
`.trim();
    expectParseError(dsl, 'is not an outcome node');
  });

  it('invalid mode value throws', () => {
    const dsl = 'dag: d\nmode: diagonal\nentry: Q1\nQ1: Q?\n  yes -> [OUT_A]\n[OUT_A]: A';
    expectParseError(dsl, 'Invalid mode');
  });

  it('throws when question defines both edges and routes', () => {
    // "no -> OUT_A" (no brackets) exits inRoutesBlock and is parsed as a plain edge,
    // leaving Q1 with both routes: and edges populated simultaneously.
    const dsl = `
dag: d
mode: elimination
entry: Q1
Q1: Q?
  routes:
    yes -> [OUT_A, OUT_B]
    no  -> [OUT_B]
  no -> OUT_A
[OUT_A]: A
[OUT_B]: B
`.trim();
    expectParseError(dsl, 'defines both edges and routes');
  });

  it('reachableNodes includes all outcomes referenced by routes', () => {
    const { reachableNodes } = parse(ELIM);
    expect(reachableNodes).toContain('OUT_PRO');
    expect(reachableNodes).toContain('OUT_NONPROFIT');
    expect(reachableNodes).toContain('Q1');
    expect(reachableNodes).toContain('Q2');
  });

  it('inline choice label only (A: label, no ->) sets choice input as pass-through', () => {
    const dsl = `
dag: d
mode: elimination
entry: Q1
Q1: Q?
  routes:
    yes -> [OUT_A, OUT_B]
    no  -> [OUT_B]
Q2: Context?
  A: First option
  B: Second option
[OUT_A]: A
[OUT_B]: B
`.trim();
    const { dag } = parse(dsl);
    const q2 = dag.nodes['Q2'];
    expect(q2.kind).toBe('question');
    if (q2.kind !== 'question') throw new Error();
    expect(q2.input.type).toBe('choice');
    if (q2.input.type !== 'choice') throw new Error();
    expect(q2.input.options).toHaveLength(2);
    expect(q2.input.options[0]).toMatchObject({ value: 'A', label: 'First option' });
    expect(q2.input.options[1]).toMatchObject({ value: 'B', label: 'Second option' });
    expect(q2.routes).toBeUndefined(); // pass-through: no routes
  });

  it('inline choice with route brackets (A: label [OUT1, OUT2]) sets both option and route', () => {
    const dsl = `
dag: d
mode: elimination
entry: Q1
Q1: Choose?
  A: Alpha option [OUT_A, OUT_B]
  B: Beta option [OUT_B]
[OUT_A]: A
[OUT_B]: B
`.trim();
    const { dag } = parse(dsl);
    const q1 = dag.nodes['Q1'];
    expect(q1.kind).toBe('question');
    if (q1.kind !== 'question') throw new Error();
    expect(q1.input.type).toBe('choice');
    if (q1.input.type !== 'choice') throw new Error();
    expect(q1.input.options).toHaveLength(2);
    expect(q1.input.options[0]).toMatchObject({ value: 'A', label: 'Alpha option' });
    expect(q1.input.options[1]).toMatchObject({ value: 'B', label: 'Beta option' });
    expect(q1.routes).toBeDefined();
    expect(q1.routes!['A']).toEqual(['OUT_A', 'OUT_B']);
    expect(q1.routes!['B']).toEqual(['OUT_B']);
  });

  it('data-warehouse-style DSL parses without error (inline choice labels with and without brackets)', () => {
    // Mirrors the shape of demos/data-wharehouse.dag
    const dsl = `
dag: DW Test
mode: elimination
entry: Q1
Q1: What is the data content?
  A: ENTITY: Specific entity data
  B: TRANSACTIONAL: Point-in-time event data
Q2: What is the integration type?
  A: FILES: Data arrives as files [OUT_COPPER]
  B: DATABASE: Direct DB access [OUT_BRONZE]
[OUT_COPPER]: Copper Layer
  description: File-based landing zone.
[OUT_BRONZE]: Bronze Layer
  description: Direct DB ingestion.
`.trim();
    const { dag } = parse(dsl);
    // Q1 is a pass-through with labelled choices
    const q1 = dag.nodes['Q1'];
    if (q1.kind !== 'question') throw new Error();
    expect(q1.input.type).toBe('choice');
    expect(q1.routes).toBeUndefined();
    // Q2 has inline routes
    const q2 = dag.nodes['Q2'];
    if (q2.kind !== 'question') throw new Error();
    expect(q2.input.type).toBe('choice');
    expect(q2.routes!['A']).toEqual(['OUT_COPPER']);
    expect(q2.routes!['B']).toEqual(['OUT_BRONZE']);
    // Outcome has description
    const copper = dag.nodes['OUT_COPPER'];
    if (copper.kind !== 'outcome') throw new Error();
    expect(copper.description).toBe('File-based landing zone.');
  });
});

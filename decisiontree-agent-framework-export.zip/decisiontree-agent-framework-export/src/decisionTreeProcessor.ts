// src/decisionTreeProcessor.ts

export type DecisionNode = {
  id: string;
  type: 'binary' | 'case' | 'arrow';
  question?: string;
  options?: Array<{ label: string; nextNodeId: string }>;
  targetNodeId?: string;
};

export type DecisionLayer = {
  id: string;
  name: string;
  nodeIds: string[];
};

export type DecisionTree = {
  startNodeId: string;
  layers: DecisionLayer[];
  nodes: DecisionNode[];
};

export function getNodeById(tree: DecisionTree, nodeId: string): DecisionNode | undefined {
  return tree.nodes.find((node) => node.id === nodeId);
}

export function getStartNode(tree: DecisionTree): DecisionNode | undefined {
  return getNodeById(tree, tree.startNodeId);
}

export function getNextNode(tree: DecisionTree, currentNode: DecisionNode, optionLabel: string): DecisionNode | undefined {
  if (currentNode.type === 'binary' || currentNode.type === 'case') {
    const option = currentNode.options?.find((opt) => opt.label === optionLabel);
    if (option) {
      return getNodeById(tree, option.nextNodeId);
    }
  } else if (currentNode.type === 'arrow' && currentNode.targetNodeId) {
    return getNodeById(tree, currentNode.targetNodeId);
  }
  return undefined;
}

export function expandTreePath(tree: DecisionTree, path: string[]): DecisionNode[] {
  // path: array of option labels chosen at each step
  const nodes: DecisionNode[] = [];
  let currentNode = getStartNode(tree);
  let i = 0;
  while (currentNode && i < path.length) {
    nodes.push(currentNode);
    currentNode = getNextNode(tree, currentNode, path[i]);
    i++;
  }
  if (currentNode) nodes.push(currentNode);
  return nodes;
}

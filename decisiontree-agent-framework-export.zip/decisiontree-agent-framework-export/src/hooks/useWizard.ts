/**
 * decision-dag — useWizard hook
 *
 * React hook that wraps the pure dag-engine functions with useState.
 * All state transitions go through the engine — the hook is thin by design.
 */

import { useState, useCallback, useMemo } from 'react';
import type { DecisionDAG } from '../lib/dag-types';
import type { WizardState, AnswerTrailEntry } from '../lib/dag-engine';
import {
  initWizard,
  advance,
  goBack,
  resetWizard,
  getPhase,
  getCurrentQuestion,
  getCurrentOutcome,
  getProgress,
  getAnswerTrail,
  getReachableOutcomes,
} from '../lib/dag-engine';
import type { QuestionNode, OutcomeNode } from '../lib/dag-types';

export interface UseWizardReturn {
  // Current state
  state: WizardState;
  phase: 'answering' | 'complete';
  progress: number;
  currentQuestion: QuestionNode | null;
  currentOutcome: OutcomeNode | null;
  answerTrail: ReadonlyArray<AnswerTrailEntry>;
  canGoBack: boolean;
  /** Elimination mode: outcomes still in play. Undefined in decision mode. */
  remainingOutcomes: ReadonlyArray<OutcomeNode> | undefined;

  // Actions
  answer: (value: string) => void;
  back: () => void;
  reset: () => void;
}

export function useWizard(dag: DecisionDAG): UseWizardReturn {
  const [state, setState] = useState<WizardState>(() => initWizard(dag));

  const phase = useMemo(() => getPhase(dag, state), [dag, state]);
  const progress = useMemo(() => getProgress(dag, state), [dag, state]);
  const currentQuestion = useMemo(() => getCurrentQuestion(dag, state), [dag, state]);
  const currentOutcome = useMemo(() => getCurrentOutcome(dag, state), [dag, state]);
  const answerTrail = useMemo(() => getAnswerTrail(dag, state), [dag, state]);
  const canGoBack = state.history.length > 0;
  const remainingOutcomes = useMemo(
    () => (dag.mode === 'elimination' ? getReachableOutcomes(dag, state) : undefined),
    [dag, state]
  );

  const answer = useCallback(
    (value: string) => {
      setState((prev) => advance(dag, prev, value));
    },
    [dag]
  );

  const back = useCallback(() => {
    setState((prev) => goBack(dag, prev));
  }, [dag]);

  const reset = useCallback(() => {
    setState(resetWizard(dag));
  }, [dag]);

  return {
    state,
    phase,
    progress,
    currentQuestion,
    currentOutcome,
    answerTrail,
    canGoBack,
    remainingOutcomes,
    answer,
    back,
    reset,
  };
}

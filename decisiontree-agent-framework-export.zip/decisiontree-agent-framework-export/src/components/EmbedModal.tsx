/**
 * decision-dag — EmbedModal
 *
 * Modal that generates copy-able iframe embed code and a direct link
 * for the current DAG. Opened from the main app top bar.
 */

import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { config } from '../config';
import { encodeDsl, buildEmbedUrl } from '../lib/embed-utils';

/** Escape a string for safe use inside an HTML attribute value. */
function escapeAttr(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

/** Validate that width/height contain only safe CSS/HTML size characters. */
function safeDimension(s: string): string {
  return /^[0-9a-zA-Z%.\s]+$/.test(s) ? s : '';
}

interface EmbedModalProps {
  dsl: string;
  dagName?: string;
  onClose: () => void;
}

function CopyButton({ text, label }: { text: string; label: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback for browsers without clipboard API
      const el = document.createElement('textarea');
      el.value = text;
      el.style.position = 'fixed';
      el.style.opacity = '0';
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  }, [text]);

  return (
    <button
      onClick={handleCopy}
      style={{
        padding: '6px 14px',
        borderRadius: 6,
        cursor: 'pointer',
        border: `1px solid ${copied ? '#5DCAA5' : 'var(--color-border-secondary, #ddd)'}`,
        background: copied ? '#E1F5EE' : 'var(--color-background-primary, #fff)',
        color: copied ? '#1D9E75' : 'var(--color-text-primary, #111)',
        fontSize: 12,
        fontWeight: 500,
        fontFamily: 'inherit',
        transition: 'all 0.15s',
        whiteSpace: 'nowrap',
        flexShrink: 0,
      }}
    >
      {copied ? '✓ Copied' : label}
    </button>
  );
}

export function EmbedModal({ dsl, dagName, onClose }: EmbedModalProps) {
  const [width, setWidth] = useState('100%');
  const [height, setHeight] = useState('600');

  const encoded = useMemo(() => encodeDsl(dsl), [dsl]);
  const embedUrl = useMemo(
    () => buildEmbedUrl(config.baseUrl, encoded),
    [encoded]
  );

  const iframeCode = useMemo(() => {
    const safeWidth = safeDimension(width) || '100%';
    const safeHeight = safeDimension(height) || '600';
    const safeTitle = escapeAttr(dagName ?? 'Decision wizard');
    return `<iframe\n  src="${escapeAttr(embedUrl)}"\n  width="${safeWidth}"\n  height="${safeHeight}"\n  style="border:none;border-radius:12px;"\n  title="${safeTitle}"\n  loading="lazy">\n</iframe>`;
  }, [embedUrl, width, height, dagName]);

  const urlTooLong = embedUrl.length > 2000;

  // Close on backdrop click or Escape key
  const handleBackdrop = useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      if (e.target === e.currentTarget) onClose();
    },
    [onClose]
  );

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, [onClose]);

  return (
    <div
      onClick={handleBackdrop}
      style={{
        position: 'fixed',
        inset: 0,
        background: 'rgba(0,0,0,0.4)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 1000,
        padding: 16,
      }}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="embed-modal-title"
        style={{
          background: 'var(--color-background-primary, #fff)',
          borderRadius: 16,
          padding: '28px 28px 24px',
          maxWidth: 560,
          width: '100%',
          maxHeight: '90vh',
          overflowY: 'auto',
          boxShadow: '0 20px 60px rgba(0,0,0,0.2)',
        }}
      >
        {/* Header */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'flex-start',
            marginBottom: 20,
          }}
        >
          <div>
            <div
              id="embed-modal-title"
              style={{
                fontSize: 16,
                fontWeight: 600,
                color: 'var(--color-text-primary, #111)',
                marginBottom: 3,
              }}
            >
              Embed this wizard
            </div>
            <div
              style={{
                fontSize: 12,
                color: 'var(--color-text-tertiary, #888)',
              }}
            >
              Paste the code below into any webpage to embed an interactive copy.
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close embed dialog"
            style={{
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              fontSize: 20,
              color: 'var(--color-text-tertiary, #aaa)',
              lineHeight: 1,
              padding: '0 0 0 12px',
              fontFamily: 'inherit',
            }}
          >
            ×
          </button>
        </div>

        {urlTooLong && (
          <div
            style={{
              background: '#FFF8E1',
              border: '1px solid #FFD54F',
              borderRadius: 8,
              padding: '10px 14px',
              marginBottom: 16,
              fontSize: 12,
              color: '#795548',
            }}
          >
            ⚠ This DAG is large — the embed URL exceeds 2 000 characters and may
            not work in some platforms. Consider simplifying the DAG.
          </div>
        )}

        {/* Size controls */}
        <div
          style={{
            display: 'flex',
            gap: 12,
            marginBottom: 20,
            alignItems: 'flex-end',
          }}
        >
          <label style={{ flex: 1 }}>
            <div
              style={{
                fontSize: 11,
                fontWeight: 600,
                color: 'var(--color-text-secondary, #666)',
                marginBottom: 4,
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
              }}
            >
              Width
            </div>
            <input
              type="text"
              value={width}
              onChange={(e) => setWidth(e.target.value)}
              placeholder="100% or 640"
              style={{
                width: '100%',
                padding: '7px 10px',
                borderRadius: 6,
                border: '1px solid var(--color-border-secondary, #ddd)',
                fontSize: 13,
                fontFamily: 'inherit',
                boxSizing: 'border-box',
                background: 'var(--color-background-primary, #fff)',
                color: 'var(--color-text-primary, #111)',
              }}
            />
          </label>
          <label style={{ flex: 1 }}>
            <div
              style={{
                fontSize: 11,
                fontWeight: 600,
                color: 'var(--color-text-secondary, #666)',
                marginBottom: 4,
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
              }}
            >
              Height (px)
            </div>
            <input
              type="text"
              value={height}
              onChange={(e) => setHeight(e.target.value)}
              placeholder="600"
              style={{
                width: '100%',
                padding: '7px 10px',
                borderRadius: 6,
                border: '1px solid var(--color-border-secondary, #ddd)',
                fontSize: 13,
                fontFamily: 'inherit',
                boxSizing: 'border-box',
                background: 'var(--color-background-primary, #fff)',
                color: 'var(--color-text-primary, #111)',
              }}
            />
          </label>
        </div>

        {/* iframe code */}
        <div style={{ marginBottom: 20 }}>
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: 6,
            }}
          >
            <div
              style={{
                fontSize: 11,
                fontWeight: 600,
                color: 'var(--color-text-secondary, #666)',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
              }}
            >
              Embed code
            </div>
            <CopyButton text={iframeCode} label="Copy code" />
          </div>
          <pre
            style={{
              background: 'var(--color-background-secondary, #f7f7f5)',
              border: '1px solid var(--color-border-tertiary, #e5e5e5)',
              borderRadius: 8,
              padding: '12px 14px',
              fontSize: 11,
              fontFamily: 'var(--font-mono, monospace)',
              overflowX: 'auto',
              margin: 0,
              color: 'var(--color-text-primary, #111)',
              lineHeight: 1.6,
              whiteSpace: 'pre-wrap',
              wordBreak: 'break-all',
            }}
          >
            {iframeCode}
          </pre>
        </div>

        {/* Direct link */}
        <div>
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: 6,
            }}
          >
            <div
              style={{
                fontSize: 11,
                fontWeight: 600,
                color: 'var(--color-text-secondary, #666)',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
              }}
            >
              Direct link
            </div>
            <CopyButton text={embedUrl} label="Copy link" />
          </div>
          <div
            style={{
              background: 'var(--color-background-secondary, #f7f7f5)',
              border: '1px solid var(--color-border-tertiary, #e5e5e5)',
              borderRadius: 8,
              padding: '10px 14px',
              fontSize: 11,
              fontFamily: 'var(--font-mono, monospace)',
              overflowX: 'auto',
              color: '#7F77DD',
              wordBreak: 'break-all',
            }}
          >
            {embedUrl}
          </div>
        </div>
      </div>
    </div>
  );
}

/**
 * decision-dag — PathVisualisation component
 *
 * Interactive layered view of the decision DAG.
 * Owns its own answer state — users answer questions directly here.
 *
 * Layout: one wide rounded-corner row per question.
 *   Left region  (~35%) — question text + step number
 *   Right region (~65%) — answer cards; selected = purple, others clickable
 *
 * Reactivity:
 *   • Decision mode: answering a question greys out questions on eliminated
 *     branches; changing an earlier answer clears downstream answers that are
 *     no longer on the active path.
 *   • Elimination mode: each answer narrows the surviving outcomes; the
 *     Elimination Matrix below updates live.
 *   • Outcome strip at the bottom greys out eliminated outcomes in real time.
 */

import React, { useState, useMemo, useCallback } from 'react';
import type { DecisionDAG, QuestionNode, OutcomeNode } from '../lib/dag-types';
import { isQuestionNode, isOutcomeNode } from '../lib/dag-types';

// ── Types ─────────────────────────────────────────────────────────────────

interface PathVisualisationProps {
  dag: DecisionDAG;
}

interface AnswerOption {
  value: string;
  label: string;
}

// ── DAG helpers (pure, no engine dependency) ──────────────────────────────

function getOrderedQuestions(dag: DecisionDAG): QuestionNode[] {
  if (dag.mode === 'elimination' && dag.questionOrder) {
    return dag.questionOrder
      .map((id) => dag.nodes[id])
      .filter((n): n is QuestionNode => isQuestionNode(n));
  }
  // BFS from entry for decision mode
  const visited = new Set<string>();
  const queue: string[] = [dag.entry];
  const result: QuestionNode[] = [];
  while (queue.length > 0) {
    const id = queue.shift()!;
    if (visited.has(id)) continue;
    visited.add(id);
    const node = dag.nodes[id];
    if (!node) continue;
    if (isQuestionNode(node)) {
      result.push(node);
      for (const edge of node.edges) {
        if (!visited.has(edge.next)) queue.push(edge.next);
      }
    }
  }
  return result;
}

function getAllOutcomes(dag: DecisionDAG): OutcomeNode[] {
  return Object.values(dag.nodes).filter((n): n is OutcomeNode =>
    isOutcomeNode(n)
  );
}

function getAnswerOptions(question: QuestionNode): AnswerOption[] {
  if (question.input.type === 'binary') {
    return [
      { value: 'yes', label: question.input.yes_label ?? 'Yes' },
      { value: 'no', label: question.input.no_label ?? 'No' },
    ];
  }
  return question.input.options.map((o) => ({
    value: o.value,
    label: o.label,
  }));
}

/**
 * Decision mode: BFS from entry, following known answers when present and all
 * edges when not yet answered. Returns the set of node IDs still reachable.
 */
function getReachableDecisionNodes(
  dag: DecisionDAG,
  answers: Record<string, string>
): Set<string> {
  const visited = new Set<string>();
  const queue: string[] = [dag.entry];
  while (queue.length > 0) {
    const id = queue.shift()!;
    if (visited.has(id)) continue;
    visited.add(id);
    const node = dag.nodes[id];
    if (!node || !isQuestionNode(node)) continue;
    const answer = answers[id];
    if (answer) {
      const edge = node.edges.find((e) => e.answer === answer);
      if (edge) queue.push(edge.next);
    } else {
      for (const edge of node.edges) queue.push(edge.next);
    }
  }
  return visited;
}

/**
 * Decision mode: walk the answered path to find the winner outcome, if any.
 */
function getDecisionWinner(
  dag: DecisionDAG,
  answers: Record<string, string>
): string | null {
  let nodeId = dag.entry;
  while (true) {
    const node = dag.nodes[nodeId];
    if (!node) return null;
    if (isOutcomeNode(node)) return nodeId;
    if (!isQuestionNode(node)) return null;
    const answer = answers[nodeId];
    if (!answer) return null;
    const edge = node.edges.find((e) => e.answer === answer);
    if (!edge) return null;
    nodeId = edge.next;
  }
}

/**
 * Elimination mode: intersect remaining outcomes from all given answers.
 * A question with no routes defined is treated as a pass-through — it does
 * not filter any outcomes (any outcome remains possible).
 */
function computeEliminationRemaining(
  dag: DecisionDAG,
  answers: Record<string, string>
): Set<string> {
  let remaining = new Set(
    Object.values(dag.nodes)
      .filter((n) => n.kind === 'outcome')
      .map((n) => n.id)
  );
  for (const [qId, answer] of Object.entries(answers)) {
    const node = dag.nodes[qId];
    if (node?.kind === 'question' && node.routes) {
      const kept = node.routes[answer];
      if (kept) remaining = new Set(kept.filter((id) => remaining.has(id)));
    }
    // If node has no routes, it is a pass-through — remaining is unchanged
  }
  return remaining;
}

// ── Elimination matrix builder ────────────────────────────────────────────

function buildEliminationMatrix(
  dag: DecisionDAG,
  questions: QuestionNode[],
  outcomes: OutcomeNode[]
): Map<string, Map<string, string[]>> {
  const matrix = new Map<string, Map<string, string[]>>();
  for (const outcome of outcomes) {
    const row = new Map<string, string[]>();
    for (const question of questions) {
      if (!question.routes) {
        row.set(question.id, []);
        continue;
      }
      const retaining: string[] = [];
      for (const [answer, kept] of Object.entries(question.routes)) {
        if (kept.includes(outcome.id)) retaining.push(answer);
      }
      row.set(question.id, retaining);
    }
    matrix.set(outcome.id, row);
  }
  return matrix;
}

// ── Sub-components ────────────────────────────────────────────────────────

interface AnswerCardButtonProps {
  label: string;
  value: string;
  isBinaryYes?: boolean;
  selected: boolean;
  disabled: boolean;
  onClick: () => void;
}

function AnswerCardButton({
  label,
  value,
  isBinaryYes,
  selected,
  disabled,
  onClick,
}: AnswerCardButtonProps) {
  const [hovered, setHovered] = useState(false);

  let bg = 'var(--color-background-primary, #fff)';
  let border = 'var(--color-border-tertiary, #e5e5e5)';
  let color = 'var(--color-text-primary, #111)';
  let fontWeight: number = 400;

  if (selected) {
    bg = '#7F77DD';
    border = '#7F77DD';
    color = '#fff';
    fontWeight = 600;
  } else if (!disabled && hovered) {
    bg = 'var(--color-background-secondary, #f7f7f5)';
    border = '#A09AE8';
    color = '#7F77DD';
  }

  const isChoice = !['yes', 'no'].includes(value);

  return (
    <button
      onClick={disabled ? undefined : onClick}
      onMouseEnter={() => !disabled && setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        flex: 1,
        minWidth: 80,
        maxWidth: 200,
        padding: '10px 14px',
        borderRadius: 8,
        border: `1.5px solid ${border}`,
        background: bg,
        color,
        fontSize: 13,
        fontWeight,
        fontFamily: 'inherit',
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled && !selected ? 0.38 : 1,
        transition: 'all 0.15s',
        display: 'flex',
        alignItems: 'center',
        gap: isChoice ? 8 : 4,
        textAlign: 'left',
        pointerEvents: disabled && !selected ? 'none' : 'auto',
      }}
    >
      {isChoice && (
        <span
          style={{
            width: 22,
            height: 22,
            borderRadius: '50%',
            background: selected ? 'rgba(255,255,255,0.25)' : '#EEEDFE',
            color: selected ? '#fff' : '#3C3489',
            fontSize: 11,
            fontWeight: 700,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexShrink: 0,
          }}
        >
          {value}
        </span>
      )}
      {!isChoice && (
        <span style={{ opacity: 0.6, fontSize: 12 }}>
          {isBinaryYes ? '✓' : '✗'}
        </span>
      )}
      {label}
    </button>
  );
}

interface QuestionRowProps {
  question: QuestionNode;
  stepNumber: number;
  answered: string | undefined;
  reachable: boolean;
  onAnswer: (questionId: string, value: string) => void;
}

function QuestionRow({
  question,
  stepNumber,
  answered,
  reachable,
  onAnswer,
}: QuestionRowProps) {
  const options = getAnswerOptions(question);
  const isAnswered = answered !== undefined;

  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 16,
        padding: '14px 18px',
        borderRadius: 12,
        border: `1.5px solid ${
          isAnswered && reachable
            ? '#A09AE8'
            : 'var(--color-border-tertiary, #e5e5e5)'
        }`,
        background:
          isAnswered && reachable
            ? 'rgba(127,119,221,0.03)'
            : 'var(--color-background-primary, #fff)',
        opacity: reachable ? 1 : 0.35,
        marginBottom: 8,
        transition: 'all 0.2s',
        minHeight: 64,
      }}
    >
      {/* Step number */}
      <div
        style={{
          width: 28,
          height: 28,
          borderRadius: '50%',
          background:
            isAnswered && reachable
              ? '#7F77DD'
              : 'var(--color-border-tertiary, #e5e5e5)',
          color:
            isAnswered && reachable
              ? '#fff'
              : 'var(--color-text-tertiary, #999)',
          fontSize: 11,
          fontWeight: 600,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexShrink: 0,
        }}
      >
        {stepNumber}
      </div>

      {/* Question text */}
      <div style={{ flex: '0 0 clamp(140px, 30%, 260px)', paddingRight: 8 }}>
        <div
          style={{
            fontFamily: 'var(--font-mono, monospace)',
            fontSize: 9,
            color: 'var(--color-text-tertiary, #999)',
            marginBottom: 3,
            letterSpacing: '0.04em',
          }}
        >
          {question.id}
        </div>
        <div
          style={{
            fontSize: 14,
            fontWeight: 500,
            color: reachable
              ? 'var(--color-text-primary, #111)'
              : 'var(--color-text-tertiary, #999)',
            lineHeight: 1.35,
          }}
        >
          {question.text}
        </div>
        {question.hint && (
          <div
            style={{
              fontSize: 11,
              color: 'var(--color-text-tertiary, #999)',
              marginTop: 3,
              lineHeight: 1.4,
            }}
          >
            {question.hint}
          </div>
        )}
      </div>

      {/* Answer cards */}
      <div
        style={{
          flex: 1,
          display: 'flex',
          flexWrap: 'wrap',
          gap: 8,
          alignItems: 'stretch',
        }}
      >
        {options.map((opt, idx) => (
          <AnswerCardButton
            key={opt.value}
            label={opt.label}
            value={opt.value}
            isBinaryYes={
              question.input.type === 'binary' ? idx === 0 : undefined
            }
            selected={answered === opt.value}
            disabled={!reachable}
            onClick={() => onAnswer(question.id, opt.value)}
          />
        ))}
      </div>
    </div>
  );
}

interface OutcomeCardProps {
  outcome: OutcomeNode;
  alive: boolean;
  winner: boolean;
}

function OutcomeCard({ outcome, alive, winner }: OutcomeCardProps) {
  const textColor = winner
    ? '#1D9E75'
    : alive
    ? 'var(--color-text-primary, #111)'
    : 'var(--color-text-tertiary, #999)';

  return (
    <div
      style={{
        padding: '10px 14px',
        borderRadius: 8,
        border: `2px solid ${
          winner
            ? '#1D9E75'
            : alive
            ? 'var(--color-border-secondary, #ddd)'
            : 'var(--color-border-tertiary, #eee)'
        }`,
        background: winner
          ? 'rgba(29,158,117,0.08)'
          : 'var(--color-background-primary, #fff)',
        opacity: alive ? 1 : 0.35,
        transition: 'all 0.3s',
        minWidth: 140,
        maxWidth: 280,
        flexShrink: 0,
      }}
    >
      <div
        style={{
          fontSize: 12,
          fontWeight: 600,
          color: textColor,
          marginBottom: outcome.description || outcome.code ? 4 : 0,
          lineHeight: 1.3,
        }}
      >
        {outcome.label}
      </div>
      {outcome.description && (
        <div
          style={{
            fontSize: 11,
            color: winner ? '#1D9E75' : 'var(--color-text-secondary, #666)',
            lineHeight: 1.45,
            marginBottom: outcome.code ? 4 : 0,
          }}
        >
          {outcome.description}
        </div>
      )}
      {outcome.code && (
        <div
          style={{
            fontSize: 10,
            color: 'var(--color-text-tertiary, #999)',
            fontFamily: 'monospace',
          }}
        >
          {outcome.code}
        </div>
      )}
    </div>
  );
}

// ── Elimination Matrix ────────────────────────────────────────────────────

interface EliminationMatrixProps {
  dag: DecisionDAG;
  questions: QuestionNode[];
  outcomes: OutcomeNode[];
  answers: Record<string, string>;
  reachableOutcomeIds: Set<string>;
  winnerId: string | null;
}

function EliminationMatrix({
  dag,
  questions,
  outcomes,
  answers,
  reachableOutcomeIds,
  winnerId,
}: EliminationMatrixProps) {
  const matrix = useMemo(
    () => buildEliminationMatrix(dag, questions, outcomes),
    [dag, questions, outcomes]
  );

  const CELL_W = 80;
  const COL_LABEL_W = 130;
  const ROW_H = 40;

  return (
    <div style={{ marginTop: 32, overflowX: 'auto' }}>
      <div
        style={{
          fontSize: 12,
          fontWeight: 600,
          color: 'var(--color-text-secondary, #666)',
          textTransform: 'uppercase',
          letterSpacing: '0.05em',
          marginBottom: 12,
        }}
      >
        Elimination Matrix
      </div>
      <table
        style={{
          borderCollapse: 'collapse',
          fontSize: 12,
          minWidth: COL_LABEL_W + questions.length * CELL_W,
        }}
      >
        <thead>
          <tr>
            <th
              style={{
                width: COL_LABEL_W,
                textAlign: 'left',
                padding: '6px 10px 6px 0',
                fontWeight: 600,
                color: 'var(--color-text-tertiary, #999)',
                borderBottom: '1px solid var(--color-border-tertiary, #e5e5e5)',
                whiteSpace: 'nowrap',
              }}
            >
              Outcome
            </th>
            {questions.map((q) => {
              const answered = answers[q.id];
              return (
                <th
                  key={q.id}
                  style={{
                    width: CELL_W,
                    minWidth: CELL_W,
                    padding: '6px 8px',
                    textAlign: 'center',
                    fontWeight: 600,
                    fontFamily: 'var(--font-mono, monospace)',
                    fontSize: 10,
                    color: answered ? '#7F77DD' : 'var(--color-text-tertiary, #999)',
                    borderBottom: `2px solid ${
                      answered ? '#7F77DD' : 'var(--color-border-tertiary, #e5e5e5)'
                    }`,
                    whiteSpace: 'nowrap',
                    maxWidth: CELL_W,
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                  }}
                  title={q.text}
                >
                  {q.id}
                  {answered && (
                    <div
                      style={{
                        fontSize: 9,
                        fontWeight: 400,
                        color: '#9990E0',
                        marginTop: 1,
                      }}
                    >
                      ={answered}
                    </div>
                  )}
                </th>
              );
            })}
          </tr>
        </thead>
        <tbody>
          {outcomes.map((outcome) => {
            const alive = reachableOutcomeIds.has(outcome.id);
            const isWinner = outcome.id === winnerId;
            const row = matrix.get(outcome.id);

            return (
              <tr key={outcome.id}>
                <td
                  style={{
                    padding: '6px 10px 6px 0',
                    fontWeight: isWinner ? 600 : 400,
                    color: isWinner
                      ? '#1D9E75'
                      : alive
                      ? 'var(--color-text-primary, #111)'
                      : 'var(--color-text-tertiary, #999)',
                    opacity: alive ? 1 : 0.4,
                    borderBottom:
                      '1px solid var(--color-border-tertiary, #e5e5e5)',
                    height: ROW_H,
                    whiteSpace: 'nowrap',
                  }}
                >
                  {outcome.label}
                  {outcome.code && (
                    <span
                      style={{
                        marginLeft: 6,
                        fontSize: 9,
                        color: 'var(--color-text-tertiary, #999)',
                        fontFamily: 'monospace',
                      }}
                    >
                      {outcome.code}
                    </span>
                  )}
                </td>
                {questions.map((q) => {
                  const retaining = row?.get(q.id) ?? [];
                  const answered = answers[q.id];
                  const activelyKept = answered
                    ? retaining.includes(answered)
                    : false;

                  let cellBg = 'transparent';
                  let cellColor = 'var(--color-text-secondary, #666)';
                  let cellBorder = 'var(--color-border-tertiary, #e5e5e5)';

                  if (retaining.length === 0) {
                    cellColor = 'var(--color-text-tertiary, #bbb)';
                  } else if (activelyKept) {
                    cellBg = isWinner
                      ? 'rgba(29,158,117,0.10)'
                      : 'rgba(127,119,221,0.10)';
                    cellColor = isWinner ? '#1D9E75' : '#7F77DD';
                    cellBorder = isWinner ? '#5DCAA5' : '#A09AE8';
                  }

                  // Pass-through question (no routes) — show neutral "all" indicator
                  const isPassThrough = !q.routes;

                  return (
                    <td
                      key={q.id}
                      style={{
                        textAlign: 'center',
                        padding: '4px 6px',
                        borderBottom:
                          '1px solid var(--color-border-tertiary, #e5e5e5)',
                        opacity: alive ? 1 : 0.35,
                        height: ROW_H,
                      }}
                    >
                      {isPassThrough ? (
                        <span
                          style={{
                            color: 'var(--color-text-tertiary, #ccc)',
                            fontSize: 12,
                          }}
                        >
                          —
                        </span>
                      ) : retaining.length > 0 ? (
                        <div
                          style={{
                            display: 'inline-block',
                            padding: '2px 8px',
                            borderRadius: 4,
                            background: cellBg,
                            border: `1px solid ${cellBorder}`,
                            color: cellColor,
                            fontSize: 11,
                            fontWeight: activelyKept ? 600 : 400,
                            transition: 'all 0.2s',
                          }}
                        >
                          {retaining.join(' / ')}
                        </div>
                      ) : (
                        <span
                          style={{
                            color: 'var(--color-border-tertiary, #e5e5e5)',
                            fontSize: 14,
                          }}
                        >
                          ✕
                        </span>
                      )}
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────

export function PathVisualisation({ dag }: PathVisualisationProps) {
  const [answers, setAnswers] = useState<Record<string, string>>({});

  const questions = useMemo(() => getOrderedQuestions(dag), [dag]);
  const allOutcomes = useMemo(() => getAllOutcomes(dag), [dag]);

  // Reset answers when the DAG changes
  React.useEffect(() => {
    setAnswers({});
  }, [dag]);

  // ── Decision mode derived state ──────────────────────────────────────────

  const reachableDecisionNodes = useMemo(() => {
    if (dag.mode === 'elimination') return null;
    return getReachableDecisionNodes(dag, answers);
  }, [dag, answers]);

  const decisionWinnerId = useMemo(() => {
    if (dag.mode === 'elimination') return null;
    return getDecisionWinner(dag, answers);
  }, [dag, answers]);

  // ── Elimination mode derived state ───────────────────────────────────────

  const eliminationRemaining = useMemo(() => {
    if (dag.mode !== 'elimination') return null;
    return computeEliminationRemaining(dag, answers);
  }, [dag, answers]);

  const allQuestionsAnswered = useMemo(() => {
    if (dag.mode !== 'elimination') return false;
    return (dag.questionOrder ?? []).every((id) => id in answers);
  }, [dag, answers]);

  const eliminationWinnerId = useMemo(() => {
    if (!eliminationRemaining) return null;
    if (eliminationRemaining.size === 1)
      return Array.from(eliminationRemaining)[0];
    return null;
  }, [eliminationRemaining]);

  // ── Unified derived values ────────────────────────────────────────────────

  const reachableOutcomeIds = useMemo((): Set<string> => {
    if (dag.mode === 'elimination') {
      return eliminationRemaining ?? new Set(allOutcomes.map((o) => o.id));
    }
    return new Set(
      allOutcomes
        .filter((o) => reachableDecisionNodes?.has(o.id) ?? true)
        .map((o) => o.id)
    );
  }, [dag, eliminationRemaining, reachableDecisionNodes, allOutcomes]);

  const winnerId =
    dag.mode === 'elimination' ? eliminationWinnerId : decisionWinnerId;

  // ── Answer handlers ───────────────────────────────────────────────────────

  const handleAnswer = useCallback(
    (questionId: string, value: string) => {
      if (dag.mode === 'elimination') {
        setAnswers((prev) => ({ ...prev, [questionId]: value }));
        return;
      }
      // Decision mode: after updating this answer, remove answers for questions
      // that are no longer on the reachable path
      setAnswers((prev) => {
        const next = { ...prev, [questionId]: value };
        const reachable = getReachableDecisionNodes(dag, next);
        const cleaned: Record<string, string> = {};
        for (const [qId, ans] of Object.entries(next)) {
          if (reachable.has(qId)) cleaned[qId] = ans;
        }
        return cleaned;
      });
    },
    [dag]
  );

  const handleReset = useCallback(() => setAnswers({}), []);

  // ── Render ────────────────────────────────────────────────────────────────

  if (questions.length === 0) {
    return (
      <div
        style={{
          color: 'var(--color-text-tertiary)',
          fontSize: 13,
          padding: '24px 0',
        }}
      >
        No questions found in DAG.
      </div>
    );
  }

  const isComplete =
    dag.mode === 'elimination' ? allQuestionsAnswered : decisionWinnerId !== null;

  return (
    <div
      style={{
        fontFamily: 'var(--font-sans, system-ui, sans-serif)',
        maxWidth: 800,
      }}
    >
      {/* Header */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: 16,
        }}
      >
        <span
          style={{
            fontSize: 13,
            fontWeight: 500,
            color: 'var(--color-text-secondary)',
          }}
        >
          {dag.name ?? 'Decision path'}
          {dag.mode === 'elimination' && (
            <span
              style={{
                marginLeft: 8,
                fontSize: 10,
                fontWeight: 600,
                letterSpacing: '0.07em',
                textTransform: 'uppercase',
                color: '#7F77DD',
                background: '#EEEDFE',
                padding: '2px 7px',
                borderRadius: 4,
              }}
            >
              elimination
            </span>
          )}
        </span>
        <button
          onClick={handleReset}
          style={{
            fontSize: 12,
            padding: '4px 10px',
            borderRadius: 5,
            cursor: 'pointer',
            border: '1px solid var(--color-border-secondary)',
            background: 'transparent',
            color: 'var(--color-text-secondary)',
            fontFamily: 'inherit',
          }}
        >
          Reset
        </button>
      </div>

      {/* Question rows */}
      {questions.map((question, idx) => {
        const reachable =
          dag.mode === 'elimination'
            ? true
            : (reachableDecisionNodes?.has(question.id) ?? true);

        return (
          <QuestionRow
            key={question.id}
            question={question}
            stepNumber={idx + 1}
            answered={answers[question.id]}
            reachable={reachable}
            onAnswer={handleAnswer}
          />
        );
      })}

      {/* Outcomes strip */}
      <div
        style={{
          marginTop: 12,
          padding: '14px 18px',
          borderRadius: 12,
          border: `1.5px solid ${
            isComplete
              ? '#5DCAA5'
              : 'var(--color-border-tertiary, #e5e5e5)'
          }`,
          background: isComplete
            ? 'rgba(29,158,117,0.03)'
            : 'var(--color-background-primary, #fff)',
          transition: 'all 0.3s',
        }}
      >
        <div
          style={{
            fontSize: 11,
            fontWeight: 600,
            color: isComplete ? '#1D9E75' : 'var(--color-text-tertiary, #999)',
            textTransform: 'uppercase',
            letterSpacing: '0.06em',
            marginBottom: 10,
          }}
        >
          {isComplete
            ? winnerId
              ? 'Result'
              : `${eliminationRemaining?.size ?? 0} outcomes match`
            : 'Outcomes'}
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
          {allOutcomes.map((outcome) => (
            <OutcomeCard
              key={outcome.id}
              outcome={outcome}
              alive={reachableOutcomeIds.has(outcome.id)}
              winner={outcome.id === winnerId}
            />
          ))}
        </div>
      </div>

      {/* Elimination matrix */}
      {dag.mode === 'elimination' && (
        <EliminationMatrix
          dag={dag}
          questions={questions}
          outcomes={allOutcomes}
          answers={answers}
          reachableOutcomeIds={reachableOutcomeIds}
          winnerId={winnerId}
        />
      )}
    </div>
  );
}

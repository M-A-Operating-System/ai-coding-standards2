/**
 * decision-dag — DslEditor component
 *
 * A live DSL editor that compiles to DecisionDAG JSON on every keystroke.
 * Shows node map, compiled JSON, parse errors, and graph statistics.
 *
 * Props:
 *   initialDsl   — starting DSL string (default: empty)
 *   onChange     — fired with the compiled DAG and raw DSL string whenever compilation succeeds
 */

import React, { useState, useCallback, useMemo } from 'react';
// Backend API endpoint
const FILE_API_URL = 'http://localhost:3030';
import type { DecisionDAG } from '../lib/dag-types';
import { parseDSL, serialiseDAG } from '../lib/dag-parser';
import type { ParseResult } from '../lib/dag-parser';

// ── Types ─────────────────────────────────────────────────────────────────

interface DslEditorProps {
  initialDsl?: string;
  onChange?: (dag: DecisionDAG, dsl: string) => void;
}

type CompileState =
  | { status: 'ok'; result: ParseResult }
  | { status: 'error'; message: string; line?: number }
  | { status: 'empty' };

// ── Helpers ───────────────────────────────────────────────────────────────

function compileSafe(dsl: string): CompileState {
  if (!dsl.trim()) return { status: 'empty' };
  try {
    const result = parseDSL(dsl);
    return { status: 'ok', result };
  } catch (e: any) {
    return {
      status: 'error',
      message: e.message ?? 'Unknown parse error',
      line: e.line,
    };
  }
}

// ── Node map ──────────────────────────────────────────────────────────────

function NodeMap({ result }: { result: ParseResult }) {
  const { dag, sharedNodes } = result;
  const questions = Object.values(dag.nodes).filter((n) => n.kind === 'question');
  const outcomes = Object.values(dag.nodes).filter((n) => n.kind === 'outcome');

  return (
    <div
      style={{
        height: 400,
        overflowY: 'auto',
        border: '1px solid var(--color-border-tertiary)',
        borderRadius: 8,
        padding: 12,
        background: 'var(--color-background-secondary)',
      }}
    >
      {questions.map((node) => {
        const isEntry = dag.entry === node.id;
        const isShared = sharedNodes.includes(node.id);
        return (
          <div
            key={node.id}
            style={{
              background: 'var(--color-background-primary)',
              border: `1px solid ${isShared ? '#EF9F27' : isEntry ? '#7F77DD' : 'var(--color-border-tertiary)'}`,
              borderRadius: 8,
              padding: '9px 12px',
              marginBottom: 6,
            }}
          >
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                marginBottom: 4,
                flexWrap: 'wrap',
              }}
            >
              <span
                style={{
                  fontFamily: 'var(--font-mono, monospace)',
                  fontSize: 11,
                  fontWeight: 600,
                  color: '#7F77DD',
                }}
              >
                {node.id}
              </span>
              {isEntry && (
                <span
                  style={{
                    fontSize: 10,
                    padding: '1px 6px',
                    borderRadius: 10,
                    background: '#EEEDFE',
                    color: '#3C3489',
                    fontWeight: 500,
                  }}
                >
                  entry
                </span>
              )}
              {isShared && (
                <span
                  style={{
                    fontSize: 10,
                    padding: '1px 6px',
                    borderRadius: 10,
                    background: '#FAEEDA',
                    color: '#633806',
                    fontWeight: 500,
                  }}
                >
                  shared
                </span>
              )}
              {node.kind === 'question' && (
                <span
                  style={{
                    fontSize: 10,
                    padding: '1px 6px',
                    borderRadius: 10,
                    background: 'var(--color-background-secondary)',
                    color: 'var(--color-text-tertiary)',
                  }}
                >
                  {node.input.type}
                </span>
              )}
            </div>
            <div
              style={{
                fontSize: 12,
                color: 'var(--color-text-secondary)',
                marginBottom: 6,
              }}
            >
              {node.kind === 'question' ? node.text : ''}
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {node.kind === 'question' &&
                node.edges.map((edge) => {
                  const isOutcome = dag.nodes[edge.next]?.kind === 'outcome';
                  return (
                    <span
                      key={edge.answer}
                      style={{
                        fontSize: 11,
                        fontFamily: 'var(--font-mono, monospace)',
                        color: 'var(--color-text-tertiary)',
                      }}
                    >
                      {edge.answer} →{' '}
                      <span style={{ color: isOutcome ? '#1D9E75' : '#7F77DD' }}>
                        {edge.next}
                      </span>
                    </span>
                  );
                })}
            </div>
          </div>
        );
      })}

      {/* Divider */}
      <div
        style={{
          borderTop: '1px solid var(--color-border-tertiary)',
          margin: '10px 0 8px',
        }}
      />

      {outcomes.map((node) => (
        <div
          key={node.id}
          style={{
            background: '#E1F5EE',
            borderRadius: 6,
            padding: '7px 12px',
            marginBottom: 5,
            display: 'flex',
            alignItems: 'center',
            gap: 10,
          }}
        >
          <span
            style={{
              fontFamily: 'var(--font-mono, monospace)',
              fontSize: 11,
              fontWeight: 600,
              color: '#085041',
              minWidth: 100,
            }}
          >
            {node.id}
          </span>
          <span style={{ fontSize: 12, color: '#085041' }}>
            {node.kind === 'outcome' ? node.label : ''}
          </span>
          {node.kind === 'outcome' && node.code && (
            <code
              style={{
                fontSize: 10,
                background: '#9FE1CB',
                color: '#085041',
                padding: '1px 6px',
                borderRadius: 3,
                marginLeft: 'auto',
              }}
            >
              {node.code}
            </code>
          )}
        </div>
      ))}
    </div>
  );
}

// ── Stats bar ─────────────────────────────────────────────────────────────

function StatsBar({ result }: { result: ParseResult }) {
  const { dag, sharedNodes, orphanNodes } = result;
  const qCount = Object.values(dag.nodes).filter((n) => n.kind === 'question').length;
  const oCount = Object.values(dag.nodes).filter((n) => n.kind === 'outcome').length;
  const isDAG = sharedNodes.length > 0;

  return (
    <div
      style={{
        display: 'flex',
        gap: 14,
        fontSize: 12,
        color: 'var(--color-text-secondary)',
        flexWrap: 'wrap',
      }}
    >
      {(
        [
          { dot: '#7F77DD', text: `${qCount} question${qCount !== 1 ? 's' : ''}` },
          { dot: '#1D9E75', text: `${oCount} outcome${oCount !== 1 ? 's' : ''}` },
          isDAG
            ? {
                dot: '#EF9F27',
                text: `${sharedNodes.length} shared node${sharedNodes.length !== 1 ? 's' : ''} · DAG`,
              }
            : { dot: '#D3D1C7', text: 'pure tree' },
          ...(orphanNodes.length > 0
            ? [{ dot: '#E24B4A', text: `${orphanNodes.length} orphan node${orphanNodes.length !== 1 ? 's' : ''}` }]
            : []),
        ] as { dot: string; text: string }[]
      ).map(({ dot, text }) => (
        <div key={text} style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
          <div
            style={{ width: 8, height: 8, borderRadius: '50%', background: dot }}
          />
          {text}
        </div>
      ))}
    </div>
  );
}

// ── DslEditor ─────────────────────────────────────────────────────────────

const DSL_HINT = `# DAG DSL quick reference
#
# dag: <n>              — document name
# version: 1.0.0          — content version
# entry: <ID>             — first question to show
#
# <ID>: Question text?    — question node
#   yes -> <ID>           — binary yes edge
#   no  -> <ID>           — binary no edge
#   A: Option label -> <ID>  — choice edge
#   hint: helper text     — shown below the question
#
# [<ID>]: Outcome label   — outcome node
#   description: text     — optional detail
#   code: MACHINE_KEY     — stable machine code`;

export function DslEditor({ initialDsl = DSL_HINT, onChange }: DslEditorProps) {
  const [dsl, setDsl] = useState<string>(initialDsl);
  const [showJson, setShowJson] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  // Save/Load state
  const [saveStatus, setSaveStatus] = useState<string>('');
  const [loadStatus, setLoadStatus] = useState<string>('');
  const [filename, setFilename] = useState<string>('example.dag');
  const [fileList, setFileList] = useState<string[]>([]);
  const [showFileList, setShowFileList] = useState<boolean>(false);

  const compiled = useMemo<CompileState>(() => compileSafe(dsl), [dsl]);

  const handleChange = useCallback(
    (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      const next = e.target.value;
      setDsl(next);
      const c = compileSafe(next);
      if (c.status === 'ok' && onChange) {
        onChange(c.result.dag, next);
      }
    },
    [onChange]
  );

  const handleCopy = useCallback(() => {
    if (compiled.status !== 'ok') return;
    const json = serialiseDAG(compiled.result.dag);
    navigator.clipboard?.writeText(json).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    });
  }, [compiled]);

  // Save DSL to backend
  const handleSave = useCallback(async () => {
    setSaveStatus('');
    try {
      const res = await fetch(`${FILE_API_URL}/save`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename, content: dsl }),
      });
      const data = await res.json();
      if (data.success) setSaveStatus('Saved!');
      else setSaveStatus(data.error || 'Save failed');
    } catch (e: any) {
      setSaveStatus('Save error');
    }
    setTimeout(() => setSaveStatus(''), 2000);
  }, [dsl, filename]);

  // Load DSL from backend
  const handleLoad = useCallback(async (fname?: string) => {
    setLoadStatus('');
    const fileToLoad = fname || filename;
    try {
      const res = await fetch(`${FILE_API_URL}/load?filename=${encodeURIComponent(fileToLoad)}`);
      const data = await res.json();
      if (data.content) {
        setDsl(data.content);
        setLoadStatus('Loaded!');
        // Parse and notify parent
        if (onChange) {
          try {
            const c = compileSafe(data.content);
            if (c.status === 'ok') {
              onChange(c.result.dag, data.content);
            }
          } catch {}
        }
      } else {
        setLoadStatus(data.error || 'Load failed');
      }
    } catch (e: any) {
      setLoadStatus('Load error');
    }
    setTimeout(() => setLoadStatus(''), 2000);
  }, [filename, onChange]);

  // List files
  const handleListFiles = useCallback(async () => {
    setShowFileList(true);
    try {
      const res = await fetch(`${FILE_API_URL}/list`);
      const data = await res.json();
      if (data.files) setFileList(data.files);
    } catch {}
  }, []);

  const labelStyle: React.CSSProperties = {
    fontSize: 11,
    fontWeight: 500,
    color: 'var(--color-text-secondary)',
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: 14,
        }}
      >
        {/* Left: DSL */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
          >
            <span style={labelStyle}>DSL source</span>
            {compiled.status === 'ok' && (
              <span
                style={{
                  fontSize: 11,
                  padding: '2px 8px',
                  borderRadius: 10,
                  background:
                    compiled.result.sharedNodes.length > 0
                      ? '#FAEEDA'
                      : '#E1F5EE',
                  color:
                    compiled.result.sharedNodes.length > 0
                      ? '#633806'
                      : '#085041',
                  fontWeight: 500,
                }}
              >
                {compiled.result.sharedNodes.length > 0
                  ? `${compiled.result.sharedNodes.length} shared · DAG`
                  : 'pure tree'}
              </span>
            )}
          </div>

          {/* Save/Load controls */}
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 4 }}>
            <input
              type="text"
              value={filename}
              onChange={e => setFilename(e.target.value)}
              placeholder="filename.dag"
              style={{ fontSize: 12, padding: '2px 8px', borderRadius: 5, border: '1px solid #ccc', width: 140 }}
            />
            <button onClick={handleSave} style={{ fontSize: 12, padding: '4px 10px', borderRadius: 5, cursor: 'pointer', border: '1px solid #bbb', background: '#F6F6F6' }}>Save</button>
            <button onClick={() => handleLoad()} style={{ fontSize: 12, padding: '4px 10px', borderRadius: 5, cursor: 'pointer', border: '1px solid #bbb', background: '#F6F6F6' }}>Load</button>
            <button onClick={handleListFiles} style={{ fontSize: 12, padding: '4px 10px', borderRadius: 5, cursor: 'pointer', border: '1px solid #bbb', background: '#F6F6F6' }}>List files</button>
            {saveStatus && <span style={{ fontSize: 11, color: '#1D9E75' }}>{saveStatus}</span>}
            {loadStatus && <span style={{ fontSize: 11, color: '#7F77DD' }}>{loadStatus}</span>}
          </div>
          {showFileList && (
            <div style={{ marginBottom: 6 }}>
              <strong>Files:</strong>{' '}
              {fileList.length === 0 ? 'No .dag files found.' : fileList.map(f => (
                <button key={f} style={{ margin: '0 4px', fontSize: 12, border: '1px solid #bbb', borderRadius: 4, background: '#F6F6F6', cursor: 'pointer' }} onClick={() => { setFilename(f); handleLoad(f); setShowFileList(false); }}>{f}</button>
              ))}
              <button style={{ marginLeft: 8, fontSize: 12, border: '1px solid #bbb', borderRadius: 4, background: '#F6F6F6', cursor: 'pointer' }} onClick={() => setShowFileList(false)}>Close</button>
            </div>
          )}

          <textarea
            value={dsl}
            onChange={handleChange}
            spellCheck={false}
            style={{
              width: '100%',
              height: 400,
              fontFamily: 'var(--font-mono, monospace)',
              fontSize: 12,
              lineHeight: 1.75,
              padding: 14,
              border: `1px solid ${compiled.status === 'error' ? 'var(--color-border-danger)' : 'var(--color-border-tertiary)'}`,
              borderRadius: 8,
              background: 'var(--color-background-secondary)',
              color: 'var(--color-text-primary)',
              resize: 'none',
              outline: 'none',
            }}
          />

          {compiled.status === 'error' && (
            <div
              style={{
                fontSize: 12,
                color: 'var(--color-text-danger)',
                background: 'var(--color-background-danger)',
                borderRadius: 6,
                padding: '8px 12px',
                lineHeight: 1.5,
                whiteSpace: 'pre-wrap',
              }}
            >
              {compiled.line ? (
                <>
                  <strong>Error at line {compiled.line}:</strong> {compiled.message}
                  <br />
                  {(() => {
                    const errLine = compiled.line!;
                    const lines = dsl.split(/\r?\n/);
                    const context = lines.slice(Math.max(0, errLine - 2), errLine + 1);
                    return context
                      .map((l, i) =>
                        (errLine - 2 + i + 1 === errLine
                          ? `> ${errLine}: ${l}`
                          : `  ${errLine - 2 + i + 1}: ${l}`)
                      )
                      .join('\n');
                  })()}
                </>
              ) : (
                compiled.message
              )}
            </div>
          )}

          <div
            style={{
              fontSize: 11,
              color: 'var(--color-text-tertiary)',
              lineHeight: 1.8,
            }}
          >
            <code>Q1: Question?</code> &nbsp;·&nbsp;{' '}
            <code>{'  '}yes/no → ID</code> &nbsp;·&nbsp;{' '}
            <code>{'  '}A: Label → ID</code> &nbsp;·&nbsp;{' '}
            <code>[OUT]: Label</code>
          </div>
        </div>

        {/* Right: output */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
          >
            <span style={labelStyle}>{showJson ? 'Compiled JSON' : 'Node map'}</span>
            {compiled.status === 'ok' && (
              <button
                onClick={() => setShowJson((v) => !v)}
                style={{
                  fontSize: 12,
                  padding: '4px 10px',
                  borderRadius: 5,
                  cursor: 'pointer',
                  border: '1px solid var(--color-border-secondary)',
                  background: 'transparent',
                  color: 'var(--color-text-secondary)',
                  fontFamily: 'inherit',
                }}
              >
                {showJson ? 'Show nodes' : 'Show JSON'}
              </button>
            )}
          </div>

          {compiled.status === 'ok' && !showJson && (
            <NodeMap result={compiled.result} />
          )}

          {compiled.status === 'ok' && showJson && (
            <pre
              style={{
                height: 400,
                fontFamily: 'var(--font-mono, monospace)',
                fontSize: 11.5,
                lineHeight: 1.7,
                padding: 14,
                border: '1px solid var(--color-border-tertiary)',
                borderRadius: 8,
                background: 'var(--color-background-secondary)',
                color: 'var(--color-text-primary)',
                margin: 0,
                overflowY: 'auto',
                whiteSpace: 'pre-wrap',
                wordBreak: 'break-word',
              }}
            >
              {serialiseDAG(compiled.result.dag)}
            </pre>
          )}

          {compiled.status !== 'ok' && (
            <div
              style={{
                height: 400,
                border: '1px solid var(--color-border-tertiary)',
                borderRadius: 8,
                background: 'var(--color-background-secondary)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'var(--color-text-tertiary)',
                fontSize: 13,
              }}
            >
              {compiled.status === 'error'
                ? 'Fix errors to see output'
                : 'Start typing to build your DAG'}
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      {compiled.status === 'ok' && (
        <div
          style={{
            display: 'flex',
            gap: 12,
            alignItems: 'center',
            flexWrap: 'wrap',
          }}
        >
          <button
            onClick={handleCopy}
            style={{
              fontSize: 12,
              padding: '6px 14px',
              borderRadius: 6,
              cursor: 'pointer',
              border: '1px solid var(--color-border-secondary)',
              background: 'var(--color-background-primary)',
              color: 'var(--color-text-primary)',
              fontFamily: 'inherit',
            }}
          >
            {copied ? 'Copied!' : 'Copy JSON to clipboard'}
          </button>
          <StatsBar result={compiled.result} />
        </div>
      )}
    </div>
  );
}

/**
 * decision-dag — WizardRunner component
 *
 * Renders the end-user wizard experience.
 * Consumes a DecisionDAG document and guides the user to an outcome.
 *
 * Props:
 *   dag        — the compiled DecisionDAG document
 *   onComplete — optional callback fired when an outcome is reached
 *   onReset    — optional callback fired when the wizard is restarted
 */

import React from 'react';
import type { DecisionDAG } from '../lib/dag-types';
import type { OutcomeNode } from '../lib/dag-types';
import { useWizard } from '../hooks/useWizard';
import type { WizardState } from '../lib/dag-engine';

// ── Types ─────────────────────────────────────────────────────────────────

interface WizardRunnerProps {
  dag: DecisionDAG;
  onComplete?: (outcome: OutcomeNode, answers: Record<string, string>) => void;
  onReset?: () => void;
  /** Called every time wizard state changes — used to sync visualisation tabs */
  onStateChange?: (state: WizardState) => void;
}

// ── Sub-components ────────────────────────────────────────────────────────

interface ProgressBarProps {
  progress: number;
}

function ProgressBar({ progress }: ProgressBarProps) {
  return (
    <div
      style={{
        height: 3,
        background: 'var(--color-border-tertiary)',
        borderRadius: 2,
        overflow: 'hidden',
        marginBottom: 28,
      }}
    >
      <div
        style={{
          height: '100%',
          width: `${progress * 100}%`,
          background: '#1D9E75',
          borderRadius: 2,
          transition: 'width 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
        }}
      />
    </div>
  );
}

// ── Question view ─────────────────────────────────────────────────────────

interface QuestionViewProps {
  node: NonNullable<ReturnType<typeof useWizard>['currentQuestion']>;
  stepNumber: number;
  canGoBack: boolean;
  onAnswer: (value: string) => void;
  onBack: () => void;
}

function QuestionView({
  node,
  stepNumber,
  canGoBack,
  onAnswer,
  onBack,
}: QuestionViewProps) {
  return (
    <div>
      <div
        style={{
          fontFamily: 'var(--font-mono, monospace)',
          fontSize: 11,
          color: 'var(--color-text-tertiary)',
          marginBottom: 10,
        }}
      >
        {node.id} · step {stepNumber}
      </div>

      <h2
        style={{
          fontSize: 22,
          fontWeight: 500,
          color: 'var(--color-text-primary)',
          margin: '0 0 8px',
          lineHeight: 1.35,
        }}
      >
        {node.text}
      </h2>

      {node.hint && (
        <p
          style={{
            fontSize: 13,
            color: 'var(--color-text-secondary)',
            margin: '0 0 24px',
            lineHeight: 1.6,
          }}
        >
          {node.hint}
        </p>
      )}

      {!node.hint && <div style={{ marginBottom: 24 }} />}

      {/* Binary input */}
      {node.input.type === 'binary' && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          {(
            [
              { value: 'yes', label: node.input.yes_label ?? 'Yes', primary: true },
              { value: 'no', label: node.input.no_label ?? 'No', primary: false },
            ] as const
          ).map(({ value, label, primary }) => (
            <button
              key={value}
              onClick={() => onAnswer(value)}
              style={{
                padding: '14px 18px',
                borderRadius: 10,
                cursor: 'pointer',
                fontSize: 15,
                fontWeight: 500,
                fontFamily: 'inherit',
                textAlign: 'left',
                border: `1.5px solid ${primary ? '#1D9E75' : 'var(--color-border-secondary)'}`,
                background: primary ? '#1D9E75' : 'var(--color-background-primary)',
                color: primary ? '#fff' : 'var(--color-text-primary)',
                transition: 'opacity 0.15s',
              }}
              onMouseEnter={(e) => ((e.target as HTMLElement).style.opacity = '0.85')}
              onMouseLeave={(e) => ((e.target as HTMLElement).style.opacity = '1')}
            >
              {label}
            </button>
          ))}
        </div>
      )}

      {/* Choice input */}
      {node.input.type === 'choice' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {node.input.options.map((opt) => (
            <button
              key={opt.value}
              onClick={() => onAnswer(opt.value)}
              style={{
                padding: '14px 18px',
                borderRadius: 10,
                cursor: 'pointer',
                fontSize: 15,
                fontFamily: 'inherit',
                textAlign: 'left',
                display: 'flex',
                alignItems: 'center',
                gap: 12,
                border: '1px solid var(--color-border-tertiary)',
                background: 'var(--color-background-primary)',
                color: 'var(--color-text-primary)',
                transition: 'border-color 0.15s, background 0.15s',
              }}
              onMouseEnter={(e) => {
                const el = e.currentTarget;
                el.style.borderColor = 'var(--color-border-primary)';
                el.style.background = 'var(--color-background-secondary)';
              }}
              onMouseLeave={(e) => {
                const el = e.currentTarget;
                el.style.borderColor = 'var(--color-border-tertiary)';
                el.style.background = 'var(--color-background-primary)';
              }}
            >
              <span
                style={{
                  width: 28,
                  height: 28,
                  borderRadius: '50%',
                  background: '#EEEDFE',
                  color: '#3C3489',
                  fontSize: 12,
                  fontWeight: 600,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0,
                }}
              >
                {opt.value}
              </span>
              <span>{opt.label}</span>
              {opt.description && (
                <span
                  style={{
                    fontSize: 12,
                    color: 'var(--color-text-tertiary)',
                    marginLeft: 'auto',
                  }}
                >
                  {opt.description}
                </span>
              )}
            </button>
          ))}
        </div>
      )}

      {/* Back button */}
      {canGoBack && (
        <button
          onClick={onBack}
          style={{
            marginTop: 20,
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            fontSize: 13,
            color: 'var(--color-text-secondary)',
            padding: 0,
            fontFamily: 'inherit',
            transition: 'color 0.15s',
          }}
          onMouseEnter={(e) =>
            ((e.target as HTMLElement).style.color = 'var(--color-text-primary)')
          }
          onMouseLeave={(e) =>
            ((e.target as HTMLElement).style.color = 'var(--color-text-secondary)')
          }
        >
          ← Back
        </button>
      )}
    </div>
  );
}

// ── Tied outcomes view ────────────────────────────────────────────────────

interface TiedOutcomesViewProps {
  outcomes: ReadonlyArray<OutcomeNode>;
  trail: ReturnType<typeof useWizard>['answerTrail'];
  onReset: () => void;
}

function TiedOutcomesView({ outcomes, trail, onReset }: TiedOutcomesViewProps) {
  return (
    <div>
      {/* Result card — multiple matches */}
      <div
        style={{
          background: '#F0EDFE',
          border: '1px solid #A09AE8',
          borderRadius: 12,
          padding: '24px 28px',
          marginBottom: 24,
        }}
      >
        <div
          style={{
            fontSize: 11,
            fontWeight: 600,
            color: '#7F77DD',
            textTransform: 'uppercase',
            letterSpacing: '0.08em',
            marginBottom: 12,
          }}
        >
          {outcomes.length} outcome{outcomes.length !== 1 ? 's' : ''} match your answers
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
          {outcomes.map((o) => (
            <div
              key={o.id}
              style={{
                padding: '10px 14px',
                borderRadius: 8,
                background: '#fff',
                border: '1px solid #A09AE8',
                minWidth: 110,
              }}
            >
              <div
                style={{
                  fontSize: 14,
                  fontWeight: 600,
                  color: '#3C3489',
                  marginBottom: o.description || o.code ? 4 : 0,
                }}
              >
                {o.label}
              </div>
              {o.description && (
                <div
                  style={{ fontSize: 12, color: '#6E67B8', lineHeight: 1.5, marginBottom: 4 }}
                >
                  {o.description}
                </div>
              )}
              {o.code && (
                <code
                  style={{
                    fontSize: 10,
                    color: '#9990E0',
                    fontFamily: 'monospace',
                    background: '#EEEDFE',
                    padding: '2px 6px',
                    borderRadius: 3,
                  }}
                >
                  {o.code}
                </code>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Answer trail */}
      <div style={{ marginBottom: 24 }}>
        <div
          style={{
            fontSize: 11,
            fontWeight: 500,
            color: 'var(--color-text-tertiary)',
            textTransform: 'uppercase',
            letterSpacing: '0.06em',
            marginBottom: 10,
          }}
        >
          Path taken · {trail.length} answer{trail.length !== 1 ? 's' : ''}
        </div>
        {trail.map((entry) => (
          <div
            key={entry.questionId}
            style={{
              display: 'flex',
              gap: 10,
              alignItems: 'baseline',
              padding: '7px 0',
              borderBottom: '1px solid var(--color-border-tertiary)',
              fontSize: 13,
            }}
          >
            <span
              style={{
                fontFamily: 'var(--font-mono, monospace)',
                fontSize: 10,
                color: 'var(--color-text-tertiary)',
                minWidth: 36,
                flexShrink: 0,
              }}
            >
              {entry.questionId}
            </span>
            <span style={{ flex: 1, color: 'var(--color-text-secondary)' }}>
              {entry.questionText}
            </span>
            <span
              style={{
                fontWeight: 500,
                color: 'var(--color-text-primary)',
                background: 'var(--color-background-secondary)',
                borderRadius: 4,
                padding: '1px 7px',
                fontSize: 12,
                whiteSpace: 'nowrap',
              }}
            >
              {entry.answerLabel}
            </span>
          </div>
        ))}
      </div>

      <button
        onClick={onReset}
        style={{
          padding: '10px 20px',
          borderRadius: 6,
          cursor: 'pointer',
          border: '1px solid var(--color-border-secondary)',
          background: 'var(--color-background-primary)',
          color: 'var(--color-text-primary)',
          fontSize: 13,
          fontFamily: 'inherit',
          transition: 'background 0.15s',
        }}
        onMouseEnter={(e) =>
          ((e.currentTarget as HTMLElement).style.background =
            'var(--color-background-secondary)')
        }
        onMouseLeave={(e) =>
          ((e.currentTarget as HTMLElement).style.background =
            'var(--color-background-primary)')
        }
      >
        Start again
      </button>
    </div>
  );
}

// ── Outcome view ──────────────────────────────────────────────────────────

interface OutcomeViewProps {
  node: OutcomeNode;
  trail: ReturnType<typeof useWizard>['answerTrail'];
  onReset: () => void;
}

function OutcomeView({ node, trail, onReset }: OutcomeViewProps) {
  return (
    <div>
      {/* Result card */}
      <div
        style={{
          background: '#E1F5EE',
          border: '1px solid #5DCAA5',
          borderRadius: 12,
          padding: '24px 28px',
          marginBottom: 24,
        }}
      >
        <div
          style={{
            fontSize: 11,
            fontWeight: 600,
            color: '#1D9E75',
            textTransform: 'uppercase',
            letterSpacing: '0.08em',
            marginBottom: 8,
          }}
        >
          Result
        </div>
        <h2
          style={{
            fontSize: 26,
            fontWeight: 500,
            color: '#085041',
            margin: '0 0 6px',
            lineHeight: 1.2,
          }}
        >
          {node.label}
        </h2>
        {node.description && (
          <p
            style={{
              fontSize: 14,
              color: '#085041',
              margin: '0 0 12px',
              lineHeight: 1.6,
              opacity: 0.8,
            }}
          >
            {node.description}
          </p>
        )}
        {node.code && (
          <code
            style={{
              background: '#9FE1CB',
              color: '#085041',
              padding: '3px 8px',
              borderRadius: 4,
              fontSize: 11,
            }}
          >
            {node.code}
          </code>
        )}
      </div>

      {/* Answer trail */}
      <div style={{ marginBottom: 24 }}>
        <div
          style={{
            fontSize: 11,
            fontWeight: 500,
            color: 'var(--color-text-tertiary)',
            textTransform: 'uppercase',
            letterSpacing: '0.06em',
            marginBottom: 10,
          }}
        >
          Path taken · {trail.length} answer{trail.length !== 1 ? 's' : ''}
        </div>

        {trail.map((entry) => (
          <div
            key={entry.questionId}
            style={{
              display: 'flex',
              gap: 10,
              alignItems: 'baseline',
              padding: '7px 0',
              borderBottom: '1px solid var(--color-border-tertiary)',
              fontSize: 13,
            }}
          >
            <span
              style={{
                fontFamily: 'var(--font-mono, monospace)',
                fontSize: 10,
                color: 'var(--color-text-tertiary)',
                minWidth: 36,
                flexShrink: 0,
              }}
            >
              {entry.questionId}
            </span>
            <span
              style={{ flex: 1, color: 'var(--color-text-secondary)' }}
            >
              {entry.questionText}
            </span>
            <span
              style={{
                fontWeight: 500,
                color: 'var(--color-text-primary)',
                background: 'var(--color-background-secondary)',
                borderRadius: 4,
                padding: '1px 7px',
                fontSize: 12,
                whiteSpace: 'nowrap',
              }}
            >
              {entry.answerLabel}
            </span>
          </div>
        ))}
      </div>

      <button
        onClick={onReset}
        style={{
          padding: '10px 20px',
          borderRadius: 6,
          cursor: 'pointer',
          border: '1px solid var(--color-border-secondary)',
          background: 'var(--color-background-primary)',
          color: 'var(--color-text-primary)',
          fontSize: 13,
          fontFamily: 'inherit',
          transition: 'background 0.15s',
        }}
        onMouseEnter={(e) =>
          ((e.currentTarget as HTMLElement).style.background =
            'var(--color-background-secondary)')
        }
        onMouseLeave={(e) =>
          ((e.currentTarget as HTMLElement).style.background =
            'var(--color-background-primary)')
        }
      >
        Start again
      </button>
    </div>
  );
}

// ── WizardRunner ──────────────────────────────────────────────────────────

export function WizardRunner({ dag, onComplete, onReset, onStateChange }: WizardRunnerProps) {
  const wizard = useWizard(dag);

  // Fire onComplete callback when outcome is first reached
  React.useEffect(() => {
    if (wizard.phase === 'complete' && wizard.currentOutcome && onComplete) {
      onComplete(
        wizard.currentOutcome,
        wizard.state.answers as Record<string, string>
      );
    }
  }, [wizard.phase, wizard.currentOutcome]);

  // Sync wizard state to parent for visualisation tabs
  React.useEffect(() => {
    onStateChange?.(wizard.state);
  }, [wizard.state, onStateChange]);

  const handleReset = () => {
    wizard.reset();
    onReset?.();
  };

  return (
    <div style={{ maxWidth: 520, margin: '0 auto' }}>
      {/* Header */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: 10,
        }}
      >
        <span
          style={{ fontSize: 13, fontWeight: 500, color: 'var(--color-text-secondary)' }}
        >
          {dag.name ?? 'Decision wizard'}
        </span>
        <button
          onClick={handleReset}
          style={{
            fontSize: 12,
            padding: '4px 10px',
            borderRadius: 5,
            cursor: 'pointer',
            border: '1px solid var(--color-border-secondary)',
            background: 'transparent',
            color: 'var(--color-text-secondary)',
            fontFamily: 'inherit',
          }}
        >
          Restart
        </button>
      </div>

      <ProgressBar progress={wizard.progress} />

      {wizard.phase === 'answering' && wizard.currentQuestion && (
        <QuestionView
          node={wizard.currentQuestion}
          stepNumber={wizard.state.history.length + 1}
          canGoBack={wizard.canGoBack}
          onAnswer={wizard.answer}
          onBack={wizard.back}
        />
      )}

      {wizard.phase === 'complete' && wizard.currentOutcome && (
        <OutcomeView
          node={wizard.currentOutcome}
          trail={wizard.answerTrail}
          onReset={handleReset}
        />
      )}

      {wizard.phase === 'complete' && !wizard.currentOutcome && wizard.remainingOutcomes && (
        <TiedOutcomesView
          outcomes={wizard.remainingOutcomes}
          trail={wizard.answerTrail}
          onReset={handleReset}
        />
      )}
    </div>
  );
}

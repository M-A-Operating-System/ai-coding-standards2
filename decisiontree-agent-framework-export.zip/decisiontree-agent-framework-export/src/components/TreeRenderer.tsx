/**
 * decision-dag — TreeRenderer component
 *
 * Renders the decision tree as a traditional flowchart:
 *   • Diamond shapes for question nodes
 *   • Rounded rectangles for outcome nodes
 *   • Labelled edges for each answer option
 *
 * Live wizard tracking:
 *   • The path taken so far is highlighted
 *   • The current node has an accent border
 *   • Branches not yet taken are dimmed
 *
 * Layout: simple top-down recursive layout. Each node is placed at a
 * horizontal position determined by the mid-point of its children.
 * Shared nodes (multiple parents) are rendered once at their first
 * encountered position.
 */

import React, { useMemo } from 'react';
import type { DecisionDAG, QuestionNode, OutcomeNode } from '../lib/dag-types';
import { isQuestionNode, isOutcomeNode } from '../lib/dag-types';
import type { WizardState } from '../lib/dag-engine';

// ── Layout constants ──────────────────────────────────────────────────────

const Q_W = 140;  // question diamond bounding-box width
const Q_H = 60;   // question diamond bounding-box height
const O_W = 130;  // outcome rect width
const O_H = 44;   // outcome rect height
const H_GAP = 24; // horizontal gap between sibling nodes
const V_GAP = 80; // vertical gap between layers

// ── Types ─────────────────────────────────────────────────────────────────

interface NodeLayout {
  id: string;
  x: number;  // centre x
  y: number;  // centre y
  kind: 'question' | 'outcome';
}

interface EdgeLayout {
  fromId: string;
  toId: string;
  label: string;
  active: boolean;   // part of the taken path
  dimmed: boolean;   // sibling of a taken edge that wasn't chosen
}

interface LayoutResult {
  nodes: NodeLayout[];
  edges: EdgeLayout[];
  width: number;
  height: number;
}

// ── Layout engine ─────────────────────────────────────────────────────────

/**
 * Compute a simple top-down layout for the DAG.
 * Uses a post-order recursive width calculation so parents are
 * centred over their children.
 */
function computeLayout(dag: DecisionDAG, wizardState?: WizardState): LayoutResult {
  const positioned = new Map<string, NodeLayout>();
  const edgeList: EdgeLayout[] = [];

  // Build taken-path set from wizard state
  const takenEdges = new Set<string>(); // "fromId:answer" pairs
  if (wizardState) {
    for (const [questionId, answer] of Object.entries(wizardState.answers)) {
      takenEdges.add(`${questionId}:${answer}`);
    }
  }

  // Subtree width in "slots" (each slot = node width + gap)
  const slotCache = new Map<string, number>();

  function subtreeSlots(id: string, visited = new Set<string>()): number {
    if (slotCache.has(id)) return slotCache.get(id)!;
    if (visited.has(id)) { slotCache.set(id, 1); return 1; }
    visited.add(id);

    const node = dag.nodes[id];
    if (!node || isOutcomeNode(node)) {
      slotCache.set(id, 1);
      return 1;
    }
    const total = node.edges.reduce(
      (sum, e) => sum + subtreeSlots(e.next, new Set(visited)),
      0
    );
    const result = Math.max(total, 1);
    slotCache.set(id, result);
    return result;
  }

  function place(id: string, cx: number, depth: number, visited = new Set<string>()): void {
    if (positioned.has(id)) return;
    if (visited.has(id)) return;
    visited.add(id);

    const node = dag.nodes[id];
    if (!node) return;

    const y = depth * (Math.max(Q_H, O_H) + V_GAP) + Math.max(Q_H, O_H) / 2 + 20;

    positioned.set(id, {
      id,
      x: cx,
      y,
      kind: node.kind,
    });

    if (isQuestionNode(node) && node.edges.length > 0) {
      // Distribute children horizontally centred under this node
      const totalSlots = node.edges.reduce(
        (sum, e) => sum + subtreeSlots(e.next),
        0
      );
      const totalWidth = totalSlots * (Q_W + H_GAP) - H_GAP;
      let childX = cx - totalWidth / 2;

      for (const edge of node.edges) {
        const slots = subtreeSlots(edge.next);
        const childWidth = slots * (Q_W + H_GAP) - H_GAP;
        const childCx = childX + childWidth / 2;
        place(edge.next, childCx, depth + 1, new Set(visited));
        childX += childWidth + H_GAP;

        const active = takenEdges.has(`${id}:${edge.answer}`);
        // An edge is dimmed if the parent question was answered but this edge was not taken
        const parentAnswered = wizardState?.answers[id] !== undefined;
        const dimmed = parentAnswered && !active;

        edgeList.push({
          fromId: id,
          toId: edge.next,
          label: edge.label ?? formatAnswerLabel(node, edge.answer),
          active,
          dimmed,
        });
      }
    }
  }

  // For elimination mode, lay out as a linear chain of questions then outcomes
  if (dag.mode === 'elimination' && dag.questionOrder) {
    const qIds = dag.questionOrder;
    const outcomes = Object.values(dag.nodes).filter(isOutcomeNode);
    const totalW = Math.max(
      qIds.length * (Q_W + H_GAP),
      outcomes.length * (O_W + H_GAP)
    );
    const centerX = totalW / 2 + 20;

    qIds.forEach((id, i) => {
      const y = i * (Q_H + V_GAP) + Q_H / 2 + 20;
      positioned.set(id, { id, x: centerX, y, kind: 'question' });

      // Connect sequential questions with a "next" edge (for display only)
      if (i > 0) {
        const prevId = qIds[i - 1];
        const prevAnswered = wizardState?.answers[prevId] !== undefined;
        edgeList.push({
          fromId: prevId,
          toId: id,
          label: '',
          active: prevAnswered,
          dimmed: false,
        });
      }
    });

    // Outcomes row
    const lastQY = (qIds.length - 1) * (Q_H + V_GAP) + Q_H / 2 + 20;
    const outY = lastQY + Q_H / 2 + V_GAP + O_H / 2;
    const outTotalW = outcomes.length * (O_W + H_GAP) - H_GAP;
    let outX = centerX - outTotalW / 2;

    for (const outcome of outcomes) {
      positioned.set(outcome.id, {
        id: outcome.id,
        x: outX + O_W / 2,
        y: outY,
        kind: 'outcome',
      });
      outX += O_W + H_GAP;
    }

    // Connect last question to all outcomes (dashed)
    if (qIds.length > 0) {
      const lastQ = qIds[qIds.length - 1];
      for (const outcome of outcomes) {
        edgeList.push({
          fromId: lastQ,
          toId: outcome.id,
          label: '',
          active: wizardState?.currentNodeId === outcome.id,
          dimmed: false,
        });
      }
    }
  } else {
    // Decision mode: recursive layout
    const rootSlots = subtreeSlots(dag.entry);
    const rootWidth = rootSlots * (Q_W + H_GAP) - H_GAP;
    place(dag.entry, rootWidth / 2 + 20, 0);
  }

  const nodes = Array.from(positioned.values());
  const maxX = nodes.reduce((m, n) => Math.max(m, n.x + Q_W / 2), 0) + 20;
  const maxY = nodes.reduce((m, n) => Math.max(m, n.y + Math.max(Q_H, O_H) / 2), 0) + 20;

  return { nodes, edges: edgeList, width: maxX, height: maxY };
}

function formatAnswerLabel(node: QuestionNode, answer: string): string {
  if (node.input.type === 'choice') {
    const opt = node.input.options.find((o) => o.value === answer);
    return opt ? opt.label : answer;
  }
  return answer.charAt(0).toUpperCase() + answer.slice(1);
}

// ── SVG helpers ───────────────────────────────────────────────────────────

/** Diamond path centred at (0,0) */
function diamondPath(w: number, h: number): string {
  return `M 0 ${-h / 2} L ${w / 2} 0 L 0 ${h / 2} L ${-w / 2} 0 Z`;
}

/** Rounded rect path centred at (0,0) */
function roundedRect(w: number, h: number, r: number): string {
  const hw = w / 2;
  const hh = h / 2;
  return (
    `M ${-hw + r} ${-hh}` +
    ` H ${hw - r} Q ${hw} ${-hh} ${hw} ${-hh + r}` +
    ` V ${hh - r} Q ${hw} ${hh} ${hw - r} ${hh}` +
    ` H ${-hw + r} Q ${-hw} ${hh} ${-hw} ${hh - r}` +
    ` V ${-hh + r} Q ${-hw} ${-hh} ${-hw + r} ${-hh} Z`
  );
}

/** Compute an orthogonal path from bottom of source to top of target */
function edgePath(
  from: NodeLayout,
  to: NodeLayout,
  fromKind: 'question' | 'outcome'
): string {
  const x1 = from.x;
  const y1 = from.y + (fromKind === 'question' ? Q_H / 2 : O_H / 2);
  const x2 = to.x;
  const y2 = to.y - (to.kind === 'question' ? Q_H / 2 : O_H / 2);
  const my = (y1 + y2) / 2;
  return `M ${x1} ${y1} C ${x1} ${my}, ${x2} ${my}, ${x2} ${y2}`;
}

// ── Component ─────────────────────────────────────────────────────────────

interface TreeRendererProps {
  dag: DecisionDAG;
  wizardState?: WizardState;
}

export function TreeRenderer({ dag, wizardState }: TreeRendererProps) {
  const layout = useMemo(() => computeLayout(dag, wizardState), [dag, wizardState]);
  const nodeMap = useMemo(
    () => new Map(layout.nodes.map((n) => [n.id, n])),
    [layout.nodes]
  );

  const currentId = wizardState?.currentNodeId;
  const isComplete =
    currentId ? dag.nodes[currentId]?.kind === 'outcome' : false;

  if (layout.nodes.length === 0) {
    return (
      <div style={{ color: 'var(--color-text-tertiary)', fontSize: 13, padding: '24px 0' }}>
        No nodes to render.
      </div>
    );
  }

  return (
    <div style={{ overflowX: 'auto', overflowY: 'auto', maxHeight: '70vh' }}>
      <svg
        width={layout.width}
        height={layout.height}
        style={{ display: 'block', fontFamily: 'var(--font-sans, system-ui, sans-serif)' }}
      >
        {/* ── Edges ── */}
        {layout.edges.map((edge, i) => {
          const from = nodeMap.get(edge.fromId);
          const to = nodeMap.get(edge.toId);
          if (!from || !to) return null;

          const d = edgePath(from, to, from.kind);
          const color = edge.active
            ? '#7F77DD'
            : edge.dimmed
            ? '#e5e5e5'
            : '#d0d0d0';
          const strokeWidth = edge.active ? 2.5 : 1.5;

          // mid-point for label
          const mx = (from.x + to.x) / 2;
          const my = (from.y + to.y) / 2;

          return (
            <g key={i}>
              <path
                d={d}
                fill="none"
                stroke={color}
                strokeWidth={strokeWidth}
                strokeDasharray={edge.dimmed ? '4 3' : undefined}
              />
              {edge.label && (
                <text
                  x={mx + 6}
                  y={my}
                  fontSize={10}
                  fill={edge.active ? '#7F77DD' : '#aaa'}
                  dominantBaseline="middle"
                >
                  {edge.label}
                </text>
              )}
            </g>
          );
        })}

        {/* ── Nodes ── */}
        {layout.nodes.map((nl) => {
          const node = dag.nodes[nl.id];
          if (!node) return null;

          const isCurrent = nl.id === currentId;
          const isWinner = isComplete && nl.id === currentId;

          if (isQuestionNode(node)) {
            const fillColor = isCurrent ? 'rgba(127,119,221,0.12)' : '#fff';
            const strokeColor = isCurrent ? '#7F77DD' : '#c8c8c8';
            const strokeW = isCurrent ? 2.5 : 1.5;
            // Truncate long text
            const label =
              node.text.length > 28 ? node.text.slice(0, 26) + '…' : node.text;

            return (
              <g key={nl.id} transform={`translate(${nl.x},${nl.y})`}>
                <path
                  d={diamondPath(Q_W, Q_H)}
                  fill={fillColor}
                  stroke={strokeColor}
                  strokeWidth={strokeW}
                />
                <title>{node.text}</title>
                <text
                  fontSize={10}
                  textAnchor="middle"
                  dominantBaseline="middle"
                  fill={isCurrent ? '#5a52cc' : '#333'}
                  style={{ pointerEvents: 'none' }}
                >
                  {label}
                </text>
              </g>
            );
          }

          if (isOutcomeNode(node)) {
            const fillColor = isWinner ? 'rgba(29,158,117,0.1)' : '#fff';
            const strokeColor = isWinner ? '#1D9E75' : '#d0d0d0';
            const strokeW = isWinner ? 2.5 : 1.5;
            const label =
              node.label.length > 20 ? node.label.slice(0, 18) + '…' : node.label;

            return (
              <g key={nl.id} transform={`translate(${nl.x},${nl.y})`}>
                <path
                  d={roundedRect(O_W, O_H, 8)}
                  fill={fillColor}
                  stroke={strokeColor}
                  strokeWidth={strokeW}
                />
                <title>{node.label}</title>
                <text
                  fontSize={10}
                  textAnchor="middle"
                  dominantBaseline="middle"
                  fill={isWinner ? '#1D9E75' : '#555'}
                  style={{ pointerEvents: 'none' }}
                >
                  {label}
                </text>
              </g>
            );
          }

          return null;
        })}
      </svg>
    </div>
  );
}

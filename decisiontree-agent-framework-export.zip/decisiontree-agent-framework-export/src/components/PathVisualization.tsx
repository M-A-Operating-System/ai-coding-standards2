import React from "react";
import "./WizardRunner.css";
import { DecisionDAG, QuestionNode, OutcomeNode } from "../lib/dag-types";

interface PathVisualizationProps {
  dag: DecisionDAG;
}

/**
 * Renders a path visualization: stacked questions (left), answer cards (right), and outcome cards (last row).
 */
const PathVisualization: React.FC<PathVisualizationProps> = ({ dag }) => {
  // Show all questions in the DAG (not just a linear path)
  const questions = Object.values(dag.nodes).filter(n => n.kind === "question") as QuestionNode[];
  const outcomes = Object.values(dag.nodes).filter(n => n.kind === "outcome") as OutcomeNode[];

  return (
    <div className="wizard-container">
      <h2>Path Visualization</h2>
      <div className="path-visualization">
        {questions.length === 0 && (
          <div style={{ color: '#b00', margin: 16 }}>No questions found in this DAG.</div>
        )}
        {questions.map((q, idx) => (
          <div className="wizard-row" key={q.id}>
            <div className="wizard-question">{q.text || q.id}</div>
            <div className="wizard-answers">
              {(q.edges && q.edges.length > 0) ? q.edges.map(edge => (
                <div className="wizard-answer-card" key={edge.answer || edge.next}>
                  <div className="wizard-answer-label">{edge.label || edge.answer || edge.next}</div>
                  <div className="wizard-next">→ {edge.next}</div>
                </div>
              )) : (
                <div className="wizard-answer-card" style={{ opacity: 0.5 }}>No answers</div>
              )}
            </div>
          </div>
        ))}
        <div className="wizard-row">
          <div className="wizard-question">Outcome</div>
          <div className="wizard-answers">
            {outcomes.length === 0 && (
              <div className="wizard-answer-card" style={{ opacity: 0.5 }}>No outcomes</div>
            )}
            {outcomes.map(outcome => (
              <div className="wizard-answer-card" key={outcome.id}>
                <div className="wizard-answer-label">{outcome.label || outcome.id}</div>
                {outcome.description && <div className="wizard-answer-desc">{outcome.description}</div>}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PathVisualization;

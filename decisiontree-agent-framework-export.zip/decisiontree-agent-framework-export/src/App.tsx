/**
 * decision-dag — App.tsx
 *
 * Top-level application shell wiring the DslEditor and WizardRunner together.
 * The two tabs share state: editing the DSL immediately updates the wizard.
 *
 * Drop this into any Lovable / Vite / CRA React project.
 * Dependencies: React 18+, TypeScript 5+
 * No external runtime dependencies beyond React itself.
 */

import React, { useState, useCallback } from 'react';
import { DslEditor } from './components/DslEditor';
import { WizardRunner } from './components/WizardRunner';
import { PathVisualisation } from './components/PathVisualisation';
import { TreeRenderer } from './components/TreeRenderer';
import { EmbedModal } from './components/EmbedModal';
import { parseDSL } from './lib/dag-parser';
import type { DecisionDAG } from './lib/dag-types';
import type { WizardState } from './lib/dag-engine';
import { initWizard } from './lib/dag-engine';

// ── Default demo DSL ──────────────────────────────────────────────────────

const DEFAULT_DSL = `dag: product-fit-assessment
version: 1.0.0
entry: Q1

Q1: Is this for a commercial organisation?
  yes -> Q2
  no  -> Q2b

Q2: How large is your team?
  A: Solo or freelance  -> Q3
  B: 2-10 people        -> Q3
  C: 11-50 people       -> Q4
  D: More than 50       -> [OUT_ENTERPRISE]

Q2b: Is this for a non-profit or public sector?
  yes -> [OUT_NONPROFIT]
  no  -> [OUT_PERSONAL]

# Q3 is a shared node — reached from Q2 options A and B
Q3: Is real-time collaboration essential?
  yes -> [OUT_TEAM]
  no  -> [OUT_PRO]

Q4: Do you require SSO or audit logging?
  yes -> [OUT_ENTERPRISE]
  no  -> [OUT_TEAM]

[OUT_PRO]:        Pro plan
  description: Best for solo users and technical individuals
  code: PLAN_PRO

[OUT_TEAM]:       Team plan
  description: Collaboration features for growing teams
  code: PLAN_TEAM

[OUT_ENTERPRISE]: Enterprise plan
  description: Advanced security and admin for large organisations
  code: PLAN_ENTERPRISE

[OUT_NONPROFIT]:  Non-profit plan
  description: Discounted access for qualifying organisations
  code: PLAN_NONPROFIT

[OUT_PERSONAL]:   Personal plan
  description: Free tier for personal and hobby projects
  code: PLAN_PERSONAL`;

// ── Helpers ───────────────────────────────────────────────────────────────

function parseOrNull(dsl: string): DecisionDAG | null {
  try {
    return parseDSL(dsl).dag;
  } catch {
    return null;
  }
}

type Tab = 'wizard' | 'path' | 'tree' | 'editor';

// ── App ───────────────────────────────────────────────────────────────────

export default function App() {
  const [tab, setTab] = useState<Tab>('wizard');
  const [dag, setDag] = useState<DecisionDAG | null>(() =>
    parseOrNull(DEFAULT_DSL)
  );
  const [hasError, setHasError] = useState<boolean>(false);
  const [wizardKey, setWizardKey] = useState<number>(0);
  const [embedOpen, setEmbedOpen] = useState<boolean>(false);
  // Keep the raw DSL in sync so EmbedModal can encode it
  const [currentDsl, setCurrentDsl] = useState<string>(DEFAULT_DSL);
  // Shared wizard state so visualisation tabs reflect live progress
  const [sharedWizardState, setSharedWizardState] = useState<WizardState | null>(
    () => {
      const d = parseOrNull(DEFAULT_DSL);
      return d ? initWizard(d) : null;
    }
  );

  const handleDagChange = useCallback((nextDag: DecisionDAG, dsl?: string) => {
    setDag(nextDag);
    setHasError(false);
    setSharedWizardState(initWizard(nextDag));
    if (dsl !== undefined) setCurrentDsl(dsl);
    // Reset the wizard when the DAG changes so stale history is cleared
    setWizardKey((k) => k + 1);
  }, []);

  const handleTabSwitch = (next: Tab) => {
    if (next === 'wizard' && dag) {
      setWizardKey((k) => k + 1);
    }
    setTab(next);
  };

  return (
    <div
      style={{
        fontFamily: 'var(--font-sans, system-ui, sans-serif)',
        minHeight: '100vh',
        background: 'var(--color-background-tertiary, #f5f4f0)',
        padding: '0 0 48px',
      }}
    >
      {/* Top bar */}
      <div
        style={{
          background: 'var(--color-background-primary, #fff)',
          borderBottom: '1px solid var(--color-border-tertiary)',
          padding: '0 24px',
          display: 'flex',
          alignItems: 'center',
          gap: 0,
        }}
      >
        <span
          style={{
            fontSize: 14,
            fontWeight: 600,
            color: 'var(--color-text-primary)',
            marginRight: 24,
            padding: '14px 0',
            letterSpacing: '-0.01em',
          }}
        >
          decision-dag
        </span>

        {(['wizard', 'path', 'tree', 'editor'] as Tab[]).map((t) => {
          const labels: Record<Tab, string> = {
            wizard: 'Run Wizard',
            path: 'Path View',
            tree: 'Tree View',
            editor: 'Build / Edit',
          };
          return (
            <button
              key={t}
              onClick={() => handleTabSwitch(t)}
              style={{
                fontSize: 13,
                padding: '14px 16px',
                cursor: 'pointer',
                border: 'none',
                background: 'transparent',
                color:
                  tab === t
                    ? 'var(--color-text-primary)'
                    : 'var(--color-text-secondary)',
                borderBottom: `2px solid ${tab === t ? '#7F77DD' : 'transparent'}`,
                fontWeight: tab === t ? 500 : 400,
                fontFamily: 'inherit',
                transition: 'all 0.15s',
              }}
            >
              {labels[t]}
              {t === 'wizard' && hasError && (
                <span
                  style={{
                    marginLeft: 5,
                    color: 'var(--color-text-danger)',
                    fontSize: 10,
                  }}
                >
                  ●
                </span>
              )}
            </button>
          );
        })}

        <div style={{ marginLeft: 'auto', display: 'flex', gap: 8, alignItems: 'center' }}>
          {dag && (
            <span
              style={{
                fontSize: 11,
                color: 'var(--color-text-tertiary)',
              }}
            >
              {dag.name ?? 'Untitled'} · v{dag.version}
            </span>
          )}
          {dag && (
            <button
              onClick={() => setEmbedOpen(true)}
              style={{
                fontSize: 12,
                padding: '5px 12px',
                borderRadius: 6,
                cursor: 'pointer',
                border: '1px solid var(--color-border-secondary)',
                background: 'transparent',
                color: 'var(--color-text-secondary)',
                fontFamily: 'inherit',
                display: 'flex',
                alignItems: 'center',
                gap: 5,
                transition: 'all 0.15s',
              }}
            >
              {'</>'}  Embed
            </button>
          )}
        </div>
      </div>

      {/* Content */}
      <div style={{ padding: '24px 24px 0' }}>
        {tab === 'editor' && (
          <DslEditor initialDsl={DEFAULT_DSL} onChange={handleDagChange} />
        )}

        {tab === 'wizard' && (
          <>
            {dag ? (
              <WizardRunner
                key={wizardKey}
                dag={dag}
                onStateChange={setSharedWizardState}
              />
            ) : (
              <div
                style={{
                  maxWidth: 520,
                  margin: '80px auto',
                  textAlign: 'center',
                  color: 'var(--color-text-tertiary)',
                  fontSize: 14,
                }}
              >
                <div style={{ marginBottom: 8 }}>No valid DAG loaded.</div>
                <div style={{ fontSize: 12 }}>
                  Switch to the Build tab and fix any errors.
                </div>
              </div>
            )}
          </>
        )}

        {tab === 'path' && (
          <div style={{ maxWidth: 840 }}>
            {dag ? (
              <PathVisualisation dag={dag} />
            ) : (
              <div style={{ color: 'var(--color-text-tertiary)', fontSize: 14 }}>
                No valid DAG loaded.
              </div>
            )}
          </div>
        )}

        {tab === 'tree' && (
          <div>
            <div
              style={{
                fontSize: 12,
                color: 'var(--color-text-tertiary)',
                marginBottom: 16,
              }}
            >
              Highlighted path updates live as you answer questions in the Run
              Wizard tab.
            </div>
            {dag ? (
              <TreeRenderer
                dag={dag}
                wizardState={sharedWizardState ?? undefined}
              />
            ) : (
              <div style={{ color: 'var(--color-text-tertiary)', fontSize: 14 }}>
                No valid DAG loaded.
              </div>
            )}
          </div>
        )}
      </div>

      {embedOpen && dag && (
        <EmbedModal
          dsl={currentDsl}
          dagName={dag.name}
          onClose={() => setEmbedOpen(false)}
        />
      )}
    </div>
  );
}

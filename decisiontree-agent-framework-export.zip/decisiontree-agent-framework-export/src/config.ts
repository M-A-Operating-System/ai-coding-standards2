/**
 * decision-dag — deployment config
 *
 * Single source of truth for deployment-specific values.
 * Override VITE_BASE_URL in your .env or hosting environment.
 */

export const config = {
  /**
   * Public base URL of this deployment.
   * Used when generating embed / share links.
   *
   * Default: VITE_BASE_URL if set. Otherwise:
   *   - production builds: the Lovable production domain
   *   - non-production builds: window.location.origin (when available)
   */
  baseUrl: (() => {
    const envBaseUrl = import.meta.env.VITE_BASE_URL as string | undefined;
    if (envBaseUrl) return envBaseUrl;

    const isProduction = import.meta.env.MODE === 'production';
    if (!isProduction && typeof window !== 'undefined' && window.location?.origin) {
      return window.location.origin;
    }

    return 'https://decisiontree.maoperatingsystem.com';
  })(),
} as const;

# Copilot Instructions

## Purpose
This file provides custom instructions for GitHub Copilot and LMMs working in this repository.

## Guidance
- Always read and follow the content of `ai-instructions/master-standards.md` before generating, reviewing, or editing any code, documentation, or standards in this repository.
- Treat the standards in `ai-instructions/master-standards.md` as authoritative for all coding, documentation, and operational practices.
- If there is a conflict between other standards and `master-standards.md`, defer to `master-standards.md`.
- Summarize or reference relevant sections from `master-standards.md` when providing recommendations or code changes.

## File Location
- The authoritative standards file is: `ai-instructions/master-standards.md`

---
_Last updated: 2026-03-31_

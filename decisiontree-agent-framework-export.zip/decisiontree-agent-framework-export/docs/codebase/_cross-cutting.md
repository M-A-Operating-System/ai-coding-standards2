# Cross-Cutting Concerns

> Last analyzed: 2026-04-09

## Immutable State Pattern

All state transitions in the engine return new objects — inputs are never mutated. `WizardState` uses `readonly` modifiers throughout. The React hook stores state via `useState` and updates it with new objects from `advance()` / `goBack()`.

This pattern spans: `dag-types.ts` (readonly interfaces), `dag-engine.ts` (immutable state updates), `useWizard.ts` (React state wrapper).

## Shared Type Contracts

The following types flow through the entire system as the canonical data contracts:

- **`DecisionDAG`** — The compiled document. Created by `parseDSL`, consumed by every engine function, every component, and the app shell.
- **`WizardState`** — Runtime state. Created by `initWizard`, updated by `advance`/`goBack`, consumed by the hook and components.
- **`QuestionNode` / `OutcomeNode`** — Node types used by the engine, hook, and visualization components.

## Pure Function Architecture

Layers 1–2 (`dag-types`, `dag-parser`, `dag-engine`) contain zero side effects. No network calls, no DOM access, no global state. This enables:
- Unit testing without mocks
- Use in server-side / edge environments
- Deterministic behavior

## Decision vs. Elimination Mode Duality

This is the most significant cross-cutting concern. The mode affects:

| File | Decision Mode Behavior | Elimination Mode Behavior |
|------|----------------------|-------------------------|
| `dag-parser.ts` | Validates edges, detects cycles | Validates routes, skips cycle detection, records `questionOrder` |
| `dag-engine.ts` | Follows edges, checks doc-level routes | Intersects remaining outcomes, advances through `questionOrder` |
| `dag-engine.ts` (progress) | `history.length / maxDepthFrom(entry)` | `history.length / questionOrder.length` |
| `dag-engine.ts` (goBack) | Simple history pop | History pop + full outcome recomputation |
| `useWizard.ts` | `remainingOutcomes` is undefined | `remainingOutcomes` populated via `getReachableOutcomes` |

## URL Encoding Pipeline

For the embed/sharing feature, the data flow is:

```
DSL string -> encodeDsl() -> base64url token -> buildEmbedUrl() -> full URL
URL -> extract `dsl` param -> decodeDsl() -> DSL string -> parseDSL() -> DecisionDAG
```

This is handled by `embed-utils.ts` (encoding) + `EmbedPage.tsx` (decoding) + `EmbedModal.tsx` (URL construction).

## Test Coverage

(Based on test file existence — detailed analysis pending)

| Test File | Covers | Lines |
|-----------|--------|-------|
| `dag-parser.test.ts` | DSL compilation, node parsing, edges, routes, error handling | ~477 |
| `dag-engine.test.ts` | Wizard navigation, state transitions, elimination mode, back navigation | ~391 |
| `embed-utils.test.ts` | Encoding/decoding round-trips, URL construction | ~53 |

No component-level tests observed. Testing focuses exclusively on the pure library layer.

# useWizard.ts

> Last analyzed: 2026-04-09

## Purpose

React hook that wraps the pure `dag-engine` functions with `useState`, providing a reactive interface for wizard navigation. Intentionally thin — all state transition logic lives in the engine.

## Module Role

React integration layer. The single bridge between the framework-agnostic engine and React components. One layer above `dag-engine.ts` in the dependency graph.

## Exports

- `UseWizardReturn` — Interface defining the hook's return shape:
  - `state: WizardState` — Current raw wizard state.
  - `phase: 'answering' | 'complete'` — Derived from `getPhase`.
  - `progress: number` — 0–1 progress value, derived from `getProgress`.
  - `currentQuestion: QuestionNode | null` — Current question or null if complete.
  - `currentOutcome: OutcomeNode | null` — Resolved outcome or null if answering.
  - `answerTrail: ReadonlyArray<AnswerTrailEntry>` — Full path taken so far.
  - `canGoBack: boolean` — True if `history.length > 0`.
  - `remainingOutcomes: ReadonlyArray<OutcomeNode> | undefined` — Elimination mode only: outcomes still in play.
  - `answer(value: string): void` — Records an answer and advances.
  - `back(): void` — Navigates to previous question.
  - `reset(): void` — Resets to initial state.

- `useWizard(dag: DecisionDAG): UseWizardReturn` — The hook itself. Accepts a `DecisionDAG` and returns the full reactive interface.

## Key Internal Functions

None — the hook delegates entirely to `dag-engine` functions.

## Dependencies

- `react` — Imports `useState`, `useCallback`, `useMemo` for React state management.
- `../lib/dag-types` — Imports `DecisionDAG`, `QuestionNode`, `OutcomeNode` for type annotations.
- `../lib/dag-engine` — Imports `WizardState`, `AnswerTrailEntry`, `initWizard`, `advance`, `goBack`, `resetWizard`, `getPhase`, `getCurrentQuestion`, `getCurrentOutcome`, `getProgress`, `getAnswerTrail`, `getReachableOutcomes`. This is the hook's entire logic source.

## Consumed By

- `src/components/WizardRunner.tsx` — The only direct consumer. Calls `useWizard(dag)` to drive the wizard UI.

## Side Effects

React state side effects only (via `useState`). No network calls, no DOM manipulation, no global state.

## Invariants / Contracts

- The hook assumes `dag` is stable across renders. If `dag` changes identity, the internal state will be stale until a reset. Callers should memoize the DAG object.
- All derived values (`phase`, `progress`, `currentQuestion`, etc.) are memoized via `useMemo` and only recompute when `dag` or `state` changes.
- Action callbacks (`answer`, `back`, `reset`) are memoized via `useCallback` with `dag` as the sole dependency.

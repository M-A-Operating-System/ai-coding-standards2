# dag-engine.ts

> Last analyzed: 2026-04-09

## Purpose

Provides pure functions for traversing a `DecisionDAG` at runtime — advancing through questions, going back, computing progress, and querying derived state. Framework-agnostic: no React, no side effects.

## Module Role

Core library — traversal engine. Sits above `dag-types.ts` and `dag-parser.ts` in the dependency graph. This is the runtime counterpart to the parser: while the parser compiles DSL to data, the engine navigates that data at runtime. Designed to be usable in Edge Functions, unit tests, or any JavaScript environment.

## Exports

### State

- `WizardState` — Interface: `{ currentNodeId: string; history: ReadonlyArray<string>; answers: Record<string, string>; remainingOutcomes?: ReadonlyArray<string> }`. Immutable state object representing the wizard's current position, answer history, and (in elimination mode) remaining viable outcomes.
- `WizardPhase` — Type: `'answering' | 'complete'`.
- `AnswerTrailEntry` — Interface: `{ questionId: string; questionText: string; answerValue: string; answerLabel: string }`. Structured representation of one step in the answer trail.

### Factory & Navigation

- `initWizard(dag: DecisionDAG): WizardState` — Creates the initial state. In elimination mode, populates `remainingOutcomes` with all outcome IDs.
- `advance(dag: DecisionDAG, state: WizardState, answer: string): WizardState` — Records the answer and moves to the next node. In decision mode, follows edges (checking document-level routes first). In elimination mode, intersects remaining outcomes with the route's kept set, then advances to the next unanswered question or resolves to an outcome. Throws if current node is an outcome or answer is invalid.
- `goBack(dag: DecisionDAG, state: WizardState): WizardState` — Pops the last question from history, removes its answer, and restores state. In elimination mode, recomputes remaining outcomes from scratch. Throws if history is empty.
- `resetWizard(dag: DecisionDAG): WizardState` — Delegates to `initWizard`.

### Derived State Queries

- `getPhase(dag, state): WizardPhase` — Returns `'complete'` if current node is an outcome, or (elimination mode) all questions have been answered.
- `getCurrentQuestion(dag, state): QuestionNode | null` — Returns the current question node, or null if complete.
- `getCurrentOutcome(dag, state): OutcomeNode | null` — Returns the resolved outcome node, or null if still answering.
- `getProgress(dag, state): number` — Returns 0–1 progress. Elimination mode: `history.length / questionOrder.length`. Decision mode: `history.length / maxDepthFrom(entry)`. Capped at 0.97 to avoid showing 100% before completion.
- `getAnswerTrail(dag, state): ReadonlyArray<AnswerTrailEntry>` — Returns the full path taken, with resolved labels for choice options.
- `getReachableOutcomes(dag, state): ReadonlyArray<OutcomeNode>` — Elimination mode: returns `remainingOutcomes` mapped to nodes. Decision mode: BFS from current node to find all reachable outcomes.

## Key Internal Functions

- `computeRemainingOutcomes(dag, answers): string[]` — Replays all answers from scratch to recompute the remaining outcome set. Used by `goBack` in elimination mode to ensure consistency after rolling back.
- `nextEliminationQuestion(dag, answers): string | null` — Returns the first question in `questionOrder` not yet answered, or null if all are done.

## Dependencies

- `./dag-types` — Imports `DecisionDAG`, `OutcomeNode`, `QuestionNode`, `isQuestionNode`, `isOutcomeNode`.
- `./dag-parser` — Imports `maxDepthFrom` for progress calculation in decision mode.

## Consumed By

- `src/hooks/useWizard.ts` — Imports `WizardState`, `AnswerTrailEntry`, `initWizard`, `advance`, `goBack`, `resetWizard`, `getPhase`, `getCurrentQuestion`, `getCurrentOutcome`, `getProgress`, `getAnswerTrail`, `getReachableOutcomes`. This is the primary consumer.
- `src/App.tsx` — Imports `WizardState`, `initWizard` for top-level state management.
- `src/components/TreeRenderer.tsx` — Imports `WizardState` to highlight the current path.
- `src/components/WizardRunner.tsx` — Imports `WizardState` for prop typing.
- `src/__tests__/dag-engine.test.ts` — Imports all navigation and query functions for unit tests.

## Side Effects

None — all functions are pure. State updates return new objects; inputs are never mutated.

## Invariants / Contracts

- `advance` throws if called on an outcome node (terminal — cannot advance).
- `advance` throws if the answer doesn't match any edge (decision) or route (elimination, non-pass-through).
- `goBack` throws if `history` is empty.
- All state transitions return new `WizardState` objects — immutability is guaranteed.
- Progress is capped at 0.97 until `getPhase` returns `'complete'`, at which point it returns 1.
- In elimination mode, when remaining outcomes narrow to 1 (or 0), the wizard resolves to that outcome even if unanswered questions remain.
- Document-level routes (`dag.routes`) take priority over edge-based traversal in decision mode.

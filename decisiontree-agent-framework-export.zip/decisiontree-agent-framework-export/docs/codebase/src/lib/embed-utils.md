# embed-utils.ts

> Last analyzed: 2026-04-09

## Purpose

Provides utilities for encoding/decoding a DAG DSL string into a URL-safe base64url token, enabling shareable embed links that carry the full DAG definition in the URL.

## Module Role

Core library — utility module. Standalone with no dependencies on other project modules. Supports the embed/sharing feature of the application.

## Exports

- `encodeDsl(dsl: string): string` — Encodes a DSL string to a URL-safe base64url token (no padding). Pipeline: UTF-8 bytes via `TextEncoder` -> binary string -> `btoa` -> base64url alphabet replacement (`+` -> `-`, `/` -> `_`, strip `=` padding).
- `decodeDsl(token: string): string` — Decodes a base64url token back to the original DSL string. Reverse of `encodeDsl`: restores standard base64 alphabet, re-adds padding, `atob` -> `Uint8Array` -> `TextDecoder`.
- `buildEmbedUrl(baseUrl: string, encodedDsl: string): string` — Constructs the full embed URL. Normalizes trailing slashes, appends `/embed` path, sets the `dsl` query parameter.

## Key Internal Functions

None — all functions are exported.

## Dependencies

None — leaf module. Uses only browser built-ins (`TextEncoder`, `TextDecoder`, `btoa`, `atob`, `URL`).

## Consumed By

- `src/components/EmbedModal.tsx` — Imports `encodeDsl`, `buildEmbedUrl` to generate embed code snippets.
- `src/pages/EmbedPage.tsx` — Imports `decodeDsl` to decode DSL from the URL on the embed page.
- `src/__tests__/embed-utils.test.ts` — Imports all three functions for unit tests.

## Side Effects

None — pure functions.

## Invariants / Contracts

- `decodeDsl(encodeDsl(s)) === s` for any valid string `s` — round-trip encoding is lossless.
- Handles any Unicode characters safely (UTF-8 encoding step).
- `buildEmbedUrl` normalizes trailing slashes on `baseUrl` to avoid double-slash paths.

# dag-types.ts

> Last analyzed: 2026-04-09

## Purpose

Defines the canonical TypeScript type contracts for the DecisionDAG format (schema version 1.0.0), consumed by both the DSL compiler and the wizard runtime.

## Module Role

Core library — foundation types. This is the lowest-level module in the dependency graph; everything else depends on it. Contains zero logic beyond two type-guard functions.

## Exports

- `ChoiceOption` — Interface: `{ value: string; label: string; description?: string }`. Represents one selectable option in a multi-choice question.
- `QuestionInput` — Discriminated union type: `{ type: 'binary'; yes_label?; no_label? } | { type: 'choice'; options: ReadonlyArray<ChoiceOption> }`. Defines the input mechanism for a question node.
- `Edge` — Interface: `{ answer: string; next: string; label?: string }`. A directed edge from a question node to the next node, triggered by a specific answer value.
- `DisplayHints` — Interface: `{ color?; icon?; position? }`. Optional renderer-facing display metadata.
- `QuestionNode` — Interface: A node of kind `'question'` with text, input config, edges (decision mode), optional routes (elimination mode), and display hints.
- `OutcomeNode` — Interface: A terminal node of kind `'outcome'` with label, description, optional machine-readable `code`, and open `payload` envelope for domain-specific data.
- `DAGNode` — Union type: `QuestionNode | OutcomeNode`.
- `DecisionDAG` — Interface: The top-level document type. Contains schema version, id, entry point, mode (`'decision' | 'elimination'`), optional `questionOrder` (elimination mode), metadata, nodes map, and optional document-level routes.
- `Route` — Interface: `{ path: ReadonlyArray<{ question: string; answers: string[] }>; outcomeId: string }`. Defines an explicit answer-path to outcome mapping.
- `isQuestionNode(node: DAGNode): node is QuestionNode` — Type guard. Returns true if `node.kind === 'question'`.
- `isOutcomeNode(node: DAGNode): node is OutcomeNode` — Type guard. Returns true if `node.kind === 'outcome'`.

## Key Internal Functions

None — all definitions are exported.

## Dependencies

None — this is a leaf module with zero imports.

## Consumed By

- `src/lib/dag-parser.ts` — Imports all node/document types for building the parsed DAG.
- `src/lib/dag-engine.ts` — Imports `DecisionDAG`, `OutcomeNode`, `QuestionNode`, `isQuestionNode`, `isOutcomeNode` for traversal logic.
- `src/hooks/useWizard.ts` — Imports `DecisionDAG`, `QuestionNode`, `OutcomeNode` for the React hook interface.
- `src/App.tsx` — Imports `DecisionDAG` for the top-level app state.
- `src/components/WizardRunner.tsx` — Imports `DecisionDAG`, `OutcomeNode`.
- `src/components/DslEditor.tsx` — Imports `DecisionDAG`.
- `src/components/TreeRenderer.tsx` — Imports `DecisionDAG`, `QuestionNode`, `OutcomeNode`, `isQuestionNode`, `isOutcomeNode`.
- `src/components/PathVisualisation.tsx` — Imports `DecisionDAG`, `QuestionNode`, `OutcomeNode`, `isQuestionNode`, `isOutcomeNode`.
- `src/components/PathVisualization.tsx` — Imports `DecisionDAG`, `QuestionNode`, `OutcomeNode`.
- `src/__tests__/dag-engine.test.ts` — Imports `DecisionDAG`.

## Side Effects

None — pure type definitions and type guards.

## Invariants / Contracts

- All properties use `readonly` modifiers — consumers must treat the data as immutable.
- `DecisionDAG.$schema_version` is always the literal `'1.0.0'`.
- `DecisionDAG.entry` must reference a valid key in `DecisionDAG.nodes` that is a `QuestionNode`.
- `Edge.next` must reference a valid key in `DecisionDAG.nodes`.
- `DecisionDAG.mode` defaults to `'decision'` when omitted.
- `questionOrder` is only meaningful in `'elimination'` mode.
- `OutcomeNode.payload` is an open envelope — its shape is not constrained by the schema.

# dag-parser.ts

> Last analyzed: 2026-04-09

## Purpose

Compiles the human-authored `.dag` DSL text format into a validated `DecisionDAG` JSON document. This is the core compiler of the system — a pure function with no side effects.

## Module Role

Core library — DSL compiler. Sits one layer above `dag-types.ts`. Consumed by the editor, the embed page, the app shell, and the engine (for depth calculation). This is the most complex single file in the codebase (~565 lines).

## Exports

- `ParseResult` — Interface: `{ dag: DecisionDAG; sharedNodes: string[]; reachableNodes: string[]; orphanNodes: string[] }`. The successful output of parsing, including graph analysis metadata.
- `ParseError` — Interface: `{ message: string; line?: number }`. Thrown on structural or referential violations during parsing.
- `parseDSL(source: string): ParseResult` — Main compiler entry point. Parses DSL source text, validates structure and references, detects cycles, and returns the compiled DAG with graph analysis. Throws `ParseError` on any violation.
- `maxDepthFrom(dag: DecisionDAG, startId: string): number` — Returns the maximum number of question nodes on any path from `startId` to any outcome. Used by the engine for progress bar calculation. Results are memoized per call via an internal cache.
- `serialiseDAG(dag: DecisionDAG): string` — Serializes a DAG to pretty-printed JSON (`JSON.stringify` with 2-space indent).
- `deserialiseDAG(json: string): DecisionDAG` — Parses JSON back to a `DecisionDAG`. Validates that `$schema_version` is `'1.0.0'`; throws `Error` otherwise.

## Key Internal Functions

- `generateUUID(): string` — Produces a UUID for the compiled DAG's `id` field. Uses `crypto.randomUUID()` when available, falls back to a Math.random-based v4 UUID generator.
- `parseRoutesSection(lines: string[]): Route[]` — Parses the document-level `routes:` section. Each line defines an explicit answer-path to outcome mapping (e.g., `Q1=yes, Q2=A -> [OUT_X]`). Supports multi-answer paths via `|` separator.
- `detectCycles(nodes, entry): void` — DFS-based cycle detection. Throws `ParseError` if any node is reachable from itself. Only runs in decision mode (elimination mode has no edges).
- `collectReachable(nodes, entry): string[]` — BFS traversal from entry node. Returns all reachable node IDs, following both edges and routes.
- `makeError(message, line?): ParseError` — Factory for `ParseError` objects.

## Dependencies

- `./dag-types` — Imports all type definitions: `DecisionDAG`, `DAGNode`, `QuestionNode`, `OutcomeNode`, `Route`, `Edge`, `ChoiceOption`, `QuestionInput`.

## Consumed By

- `src/lib/dag-engine.ts` — Imports `maxDepthFrom` for progress calculation.
- `src/App.tsx` — Imports `parseDSL` to compile the embedded demo DSL.
- `src/components/DslEditor.tsx` — Imports `parseDSL`, `serialiseDAG`, `ParseResult` for live editing.
- `src/pages/EmbedPage.tsx` — Imports `parseDSL` to compile decoded DSL in embed mode.
- `src/__tests__/dag-parser.test.ts` — Imports `parseDSL` for unit tests.
- `src/__tests__/dag-engine.test.ts` — Imports `parseDSL` to build test DAGs.

## Side Effects

None — all functions are pure. UUID generation uses `crypto.randomUUID()` or `Math.random()` but produces no observable side effects.

## Invariants / Contracts

- `parseDSL` requires an `entry:` directive; throws if missing.
- Entry node must exist and must be a `QuestionNode`.
- In decision mode: every question must have at least one edge; every edge target must exist.
- In elimination mode: questions without routes are treated as pass-throughs; route targets must be outcome nodes.
- A question cannot define both edges and routes simultaneously.
- Cycles are rejected in decision mode via DFS.
- Node IDs must be unique; duplicates cause a `ParseError`.
- Outcome IDs use `[UPPER_CASE_ID]` syntax; question IDs use bare alphanumeric identifiers.
- `deserialiseDAG` requires `$schema_version === '1.0.0'`.

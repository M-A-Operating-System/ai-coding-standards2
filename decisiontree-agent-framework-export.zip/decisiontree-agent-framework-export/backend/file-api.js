// Simple Node.js/Express backend for saving/loading DSL files
const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = 3030;
const FILES_DIR = path.join(__dirname, '../demos');

app.use(cors());
app.use(express.json());

// Save DSL file
app.post('/save', (req, res) => {
  const { filename, content } = req.body;
  if (!filename || !content) {
    return res.status(400).json({ error: 'Missing filename or content' });
  }
  const filePath = path.join(FILES_DIR, filename);
  fs.writeFile(filePath, content, (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ success: true });
  });
});

// List DSL files
app.get('/list', (req, res) => {
  fs.readdir(FILES_DIR, (err, files) => {
    if (err) return res.status(500).json({ error: err.message });
    const dagFiles = files.filter(f => f.endsWith('.dag'));
    res.json({ files: dagFiles });
  });
});

// Load DSL file
app.get('/load', (req, res) => {
  const { filename } = req.query;
  if (!filename) return res.status(400).json({ error: 'Missing filename' });
  const filePath = path.join(FILES_DIR, filename);
  fs.readFile(filePath, 'utf8', (err, data) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ content: data });
  });
});

app.listen(PORT, () => {
  console.log(`File API server running on http://localhost:${PORT}`);
});

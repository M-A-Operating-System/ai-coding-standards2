# decision-dag

A portable, human-authored format for guided decision wizards — with a live DSL compiler and React wizard runtime.

## What is this?

A decision DAG (Directed Acyclic Graph) lets you author a guided question flow where:

- Questions are binary (Yes / No) or multi-choice (A / B / C / D)
- Some questions are shared — reached from multiple branches without duplication
- Every path ends at one of a fixed set of outcomes
- A pure tree is just a DAG where every node has one incoming edge — the same format handles both

---

## File structure

```
src/
  lib/
    dag-types.ts      — TypeScript types (DecisionDAG, QuestionNode, OutcomeNode, ...)
    dag-parser.ts     — DSL → DecisionDAG compiler (pure function)
    dag-engine.ts     — Wizard traversal engine (pure functions, no React)
  hooks/
    useWizard.ts      — React hook wrapping the engine
  components/
    DslEditor.tsx     — Live DSL editor with compiled output
    WizardRunner.tsx  — End-user guided wizard UI
  App.tsx             — Top-level shell wiring both components

demos/
  product-fit.dag             — Binary + choice mix with a shared node (DAG)
  eligibility-check.dag       — Pure binary tree with early exits
  infrastructure-assessment.dag — Full DAG with multiple convergence points

schema/
  decision-dag.v1.schema.json — JSON Schema Draft 2020-12 for the compiled format
```

---

## DSL syntax

The `.dag` format compiles to the `DecisionDAG` JSON schema. Comments begin with `#`.

```
dag: My assessment name
version: 1.0.0
entry: Q1

# Binary question
Q1: Is this for a commercial organisation?
  yes -> Q2
  no  -> Q2b

# Choice question (A–F)
Q2: How large is your team?
  A: Solo or freelance  -> Q3
  B: 2-10 people        -> Q3
  C: 11-50 people       -> Q4
  D: More than 50       -> [OUT_ENTERPRISE]

# Shared node — Q3 is referenced by Q2 options A and B
Q3: Is real-time collaboration essential?
  hint: Hint text shown below the question
  yes -> [OUT_TEAM]
  no  -> [OUT_PRO]

Q4: Do you require SSO or audit logging?
  yes -> [OUT_ENTERPRISE]
  no  -> [OUT_TEAM]

# Outcomes
[OUT_PRO]: Pro plan
  description: Best for solo users
  code: PLAN_PRO

[OUT_TEAM]: Team plan
  description: For growing teams
  code: PLAN_TEAM

[OUT_ENTERPRISE]: Enterprise plan
  code: PLAN_ENTERPRISE
```

## DSL Syntax

...existing code...

### Route-based Outcomes (NEW)

You can now define explicit answer paths that lead to outcomes, using a `routes:` section at the end of your DSL file. Each route specifies a combination of answers that, if matched, will immediately produce the specified outcome.

**Syntax:**

```
|--------|-------------|
| `dag: <name>` | Document name (header directive) |
| `version: 1.0.0` | Content semver (independent of schema version) |
| `entry: <ID>` | ID of the first question to show |

- `Q1=A|B` means the route matches if Q1 is answered A or B.
- You can combine multiple questions and answers for complex logic.
- The first matching route is used.

**Example:**

```
| `<ID>: Question text?` | Define a question node |
| `  yes -> <ID>` | Binary yes edge |
| `  no  -> <ID>` | Binary no edge |
| `  A: Label -> <ID>` | Choice edge (A–F) |
| `  hint: text` | Helper text shown below question |
| `[<ID>]: Label` | Define an outcome node |
| `  description: text` | Outcome detail shown on result screen |
| `  code: MACHINE_KEY` | Stable machine-readable code |
| `# comment` | Ignored |

---

## Compiled JSON format

The DSL compiles to a validated `DecisionDAG` document:

```json
{
  "$schema_version": "1.0.0",
  "id": "f47ac10b-...",
  "name": "My assessment",
  "version": "1.0.0",
  "entry": "Q1",
  "nodes": {
    "Q1": {
      "id": "Q1",
      "kind": "question",
      "text": "Is this for a commercial organisation?",
      "input": { "type": "binary" },
      "edges": [
        { "answer": "yes", "next": "Q2" },
        { "answer": "no",  "next": "Q2b" }
      ]
    },
    "OUT_PRO": {
      "id": "OUT_PRO",
      "kind": "outcome",
      "label": "Pro plan",
      "description": "Best for solo users",
      "code": "PLAN_PRO"
    }
  }
}
```

The full JSON Schema is at `schema/decision-dag.v1.schema.json`.

---

## React usage

### WizardRunner

```tsx
import { WizardRunner } from './components/WizardRunner';
import { parseDSL } from './lib/dag-parser';

const { dag } = parseDSL(myDslString);

<WizardRunner
  dag={dag}
  onComplete={(outcome, answers) => {
    console.log('Outcome:', outcome.code, answers);
  }}
/>
```

### DslEditor

```tsx
import { DslEditor } from './components/DslEditor';
import type { DecisionDAG } from './lib/dag-types';

<DslEditor
  initialDsl={myDslString}
  onChange={(dag: DecisionDAG) => {
    // Called on every successful compilation
    saveDagToSupabase(dag);
  }}
/>
```

### useWizard hook

```tsx
import { useWizard } from './hooks/useWizard';

function MyWizard({ dag }) {
  const { currentQuestion, currentOutcome, progress, answer, back, canGoBack } =
    useWizard(dag);

  if (currentOutcome) return <ResultScreen outcome={currentOutcome} />;
  if (!currentQuestion) return null;

  return (
    <div>
      <progress value={progress} />
      <h2>{currentQuestion.text}</h2>
      <button onClick={() => answer('yes')}>Yes</button>
      <button onClick={() => answer('no')}>No</button>
      {canGoBack && <button onClick={back}>Back</button>}
    </div>
  );
}
```

### Pure engine (no React)

```typescript
import { parseDSL } from './lib/dag-parser';
import { initWizard, advance, getCurrentOutcome } from './lib/dag-engine';

const { dag } = parseDSL(dslSource);
let state = initWizard(dag);

state = advance(dag, state, 'yes');  // Answer Q1
state = advance(dag, state, 'A');    // Answer Q2

const outcome = getCurrentOutcome(dag, state);
if (outcome) console.log(outcome.code); // e.g. "PLAN_PRO"
```

---

## Schema validation invariants

Any producer or consumer must enforce:

1. Every `next` reference in an edge must resolve to an existing node in `nodes`
2. `entry` must refer to a node with `kind: "question"`
3. Every `QuestionNode` must have exactly one edge per possible answer value
4. The graph must be acyclic — detected at parse time by DFS
5. Every node must be reachable from `entry` — orphan nodes produce a warning
6. Node `id` must equal its key in the `nodes` map
7. `$schema_version` must be `"1.0.0"` — consumers reject unknown versions
8. `display` hints are optional — headless consumers must work without them

---

## Versioning

| Change | Version bump |
|--------|-------------|
| Add a new question or outcome node | Minor (`1.1.0`) |
| Add a new edge to an existing node | Minor |
| Remove or rename a node | **Major** (`2.0.0`) |
| Change an answer value (e.g. "yes" → "Y") | **Major** |
| Change `label` or `description` text | Patch (`1.0.1`) |

The document `version` tracks content changes. `$schema_version` tracks format changes. They are independent.

---

## Dependencies

- React 18+
- TypeScript 5+
- No external runtime dependencies beyond React
